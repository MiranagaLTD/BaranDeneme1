# Time ago parser raw resources

This directory contains some JSON-formatted time ago strings gather directly from YouTube.

#### Java directory

Some useful classes that can generate an overview and check if we have all the time units for all the languages.

It also contains the resource bundle generator.

#### Times directory

All the units organized by their unit value and name (e.g. 1s = "1 second", 2y = "2 años", 4w = "4 semanas").
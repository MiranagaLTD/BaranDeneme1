package com.baran.baba.yapti.stream;


import com.baran.baba.yapti.InfoItem;
import com.baran.baba.yapti.localization.DateWrapper;

import javax.annotation.Nullable;

/**
 * Info object for previews of unopened videos, eg search results, related videos
 */
public class StreamInfoItem extends InfoItem {
    private final StreamType streamType;

    private String uploaderName;
    private String textualUploadDate;
    @Nullable private DateWrapper uploadDate;
    private long viewCount = -1;
    private long duration = -1;

    private String uploaderUrl = null;

    public StreamInfoItem(int serviceId, String url, String name, StreamType streamType) {
        super(InfoType.STREAM, serviceId, url, name);
        this.streamType = streamType;
    }

    public StreamType getStreamType() {
        return streamType;
    }

    public String getUploaderName() {
        return uploaderName;
    }

    public void setUploaderName(String uploader_name) {
        this.uploaderName = uploader_name;
    }

    public long getViewCount() {
        return viewCount;
    }

    public void setViewCount(long view_count) {
        this.viewCount = view_count;
    }

    public long getDuration() {
        return duration;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }

    public String getUploaderUrl() {
        return uploaderUrl;
    }

    public void setUploaderUrl(String uploaderUrl) {
        this.uploaderUrl = uploaderUrl;
    }

    @Nullable
    public String getTextualUploadDate() {
        return textualUploadDate;
    }

    public void setTextualUploadDate(String uploadDate) {
        this.textualUploadDate = uploadDate;
    }

    @Nullable
    public DateWrapper getUploadDate() {
        return uploadDate;
    }

    public void setUploadDate(@Nullable DateWrapper uploadDate) {
        this.uploadDate = uploadDate;
    }

    @Override
    public String toString() {
        return "StreamInfoItem{" +
                "streamType=" + streamType +
                ", uploaderName='" + uploaderName + '\'' +
                ", textualUploadDate='" + textualUploadDate + '\'' +
                ", viewCount=" + viewCount +
                ", duration=" + duration +
                ", uploaderUrl='" + uploaderUrl + '\'' +
                ", infoType=" + getInfoType() +
                ", serviceId=" + getServiceId() +
                ", url='" + getUrl() + '\'' +
                ", name='" + getName() + '\'' +
                ", thumbnailUrl='" + getThumbnailUrl() + '\'' +
                '}';
    }
}
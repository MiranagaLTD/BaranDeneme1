package com.baran.baba.yapti.exceptions;


public class ReCaptchaException extends ExtractionException {
    private String url;

    public ReCaptchaException(String message, String url) {
        super(message);
        this.url = url;
    }

    public String getUrl() {
        return url;
    }
}

package com.baran.baba.yapti.services.media_ccc.extractors;

import com.baran.baba.yapti.InfoItem;
import com.baran.baba.yapti.ListExtractor;
import com.baran.baba.yapti.StreamingService;
import com.baran.baba.yapti.channel.ChannelInfoItem;
import com.baran.baba.yapti.channel.ChannelInfoItemExtractor;
import com.baran.baba.yapti.search.InfoItemsSearchCollector;
import com.baran.baba.yapti.search.SearchExtractor;
import com.grack.nanojson.JsonArray;
import com.grack.nanojson.JsonObject;
import com.grack.nanojson.JsonParser;
import com.grack.nanojson.JsonParserException;
import com.baran.baba.yapti.downloader.Downloader;
import com.baran.baba.yapti.exceptions.ExtractionException;
import com.baran.baba.yapti.exceptions.ParsingException;
import com.baran.baba.yapti.linkhandler.SearchQueryHandler;
import com.baran.baba.yapti.services.media_ccc.extractors.infoItems.MediaCCCStreamInfoItemExtractor;
import com.baran.baba.yapti.services.media_ccc.linkHandler.MediaCCCConferencesListLinkHandlerFactory;

import javax.annotation.Nonnull;
import java.io.IOException;
import java.util.List;

import static com.baran.baba.yapti.services.media_ccc.linkHandler.MediaCCCSearchQueryHandlerFactory.*;

public class MediaCCCSearchExtractor extends SearchExtractor {

    private JsonObject doc;
    private MediaCCCConferenceKiosk conferenceKiosk;

    public MediaCCCSearchExtractor(StreamingService service, SearchQueryHandler linkHandler) {
        super(service, linkHandler);
        try {
            conferenceKiosk = new MediaCCCConferenceKiosk(service,
                    new MediaCCCConferencesListLinkHandlerFactory().fromId("conferences"),
                    "conferences");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public String getSearchSuggestion() throws ParsingException {
        return null;
    }

    @Nonnull
    @Override
    public ListExtractor.InfoItemsPage<InfoItem> getInitialPage() throws IOException, ExtractionException {
        InfoItemsSearchCollector searchItems = getInfoItemSearchCollector();
        searchItems.reset();

        if(getLinkHandler().getContentFilters().contains(CONFERENCES)
                || getLinkHandler().getContentFilters().contains(ALL)
                || getLinkHandler().getContentFilters().isEmpty()) {
            searchConferences(getSearchString(),
                    conferenceKiosk.getInitialPage().getItems(),
                    searchItems);
        }

        if(getLinkHandler().getContentFilters().contains(EVENTS)
                || getLinkHandler().getContentFilters().contains(ALL)
                || getLinkHandler().getContentFilters().isEmpty()) {
            JsonArray events = doc.getArray("events");
            for (int i = 0; i < events.size(); i++) {
                searchItems.commit(new MediaCCCStreamInfoItemExtractor(
                        events.getObject(i)));
            }
        }
        return new ListExtractor.InfoItemsPage<>(searchItems, null);
    }

    @Override
    public String getNextPageUrl() throws IOException, ExtractionException {
        return "";
    }

    @Override
    public ListExtractor.InfoItemsPage<InfoItem> getPage(String pageUrl) throws IOException, ExtractionException {
        return ListExtractor.InfoItemsPage.emptyPage();
    }

    @Override
    public void onFetchPage(@Nonnull Downloader downloader) throws IOException, ExtractionException {
        if(getLinkHandler().getContentFilters().contains(EVENTS)
            || getLinkHandler().getContentFilters().contains(ALL)
                || getLinkHandler().getContentFilters().isEmpty()) {
            final String site;
            final String url = getUrl();
            site = downloader.get(url, getExtractorLocalization()).responseBody();
            try {
                doc = JsonParser.object().from(site);
            } catch (JsonParserException jpe) {
                throw new ExtractionException("Could not parse json.", jpe);
            }
        }
        if(getLinkHandler().getContentFilters().contains(CONFERENCES)
                || getLinkHandler().getContentFilters().contains(ALL)
                || getLinkHandler().getContentFilters().isEmpty())
        conferenceKiosk.fetchPage();
    }

    private void searchConferences(String searchString,
                                                    List<ChannelInfoItem> channelItems,
                                                    InfoItemsSearchCollector collector) {
        for(final ChannelInfoItem item : channelItems) {
            if(item.getName().toUpperCase().contains(
                    searchString.toUpperCase())) {
                collector.commit(new ChannelInfoItemExtractor() {
                    @Override
                    public String getDescription() throws ParsingException {
                        return item.getDescription();
                    }

                    @Override
                    public long getSubscriberCount() throws ParsingException {
                        return item.getSubscriberCount();
                    }

                    @Override
                    public long getStreamCount() throws ParsingException {
                        return item.getStreamCount();
                    }

                    @Override
                    public String getName() throws ParsingException {
                        return item.getName();
                    }

                    @Override
                    public String getUrl() throws ParsingException {
                        return item.getUrl();
                    }

                    @Override
                    public String getThumbnailUrl() throws ParsingException {
                        return item.getThumbnailUrl();
                    }
                });
            }
        }
    }
}

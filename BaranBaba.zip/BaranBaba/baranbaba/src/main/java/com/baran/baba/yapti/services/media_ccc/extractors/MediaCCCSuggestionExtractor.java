package com.baran.baba.yapti.services.media_ccc.extractors;

import com.baran.baba.yapti.StreamingService;
import com.baran.baba.yapti.exceptions.ExtractionException;
import com.baran.baba.yapti.suggestion.SuggestionExtractor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MediaCCCSuggestionExtractor extends SuggestionExtractor {

    public MediaCCCSuggestionExtractor(StreamingService service) {
        super(service);
    }

    @Override
    public List<String> suggestionList(String query) throws IOException, ExtractionException {
        return new ArrayList<>(0);
    }
}

package com.baran.baba.yapti.channel;

import com.baran.baba.yapti.InfoItemsCollector;
import com.baran.baba.yapti.exceptions.ParsingException;


public class ChannelInfoItemsCollector extends InfoItemsCollector<ChannelInfoItem, ChannelInfoItemExtractor> {
    public ChannelInfoItemsCollector(int serviceId) {
        super(serviceId);
    }

    @Override
    public ChannelInfoItem extract(ChannelInfoItemExtractor extractor) throws ParsingException {
        // important information
        int serviceId = getServiceId();
        String name = extractor.getName();
        String  url = extractor.getUrl();

        ChannelInfoItem resultItem = new ChannelInfoItem(serviceId, url, name);


        // optional information
        try {
            resultItem.setSubscriberCount(extractor.getSubscriberCount());
        } catch (Exception e) {
            addError(e);
        }
        try {
            resultItem.setStreamCount(extractor.getStreamCount());
        } catch (Exception e) {
            addError(e);
        }
        try {
            resultItem.setThumbnailUrl(extractor.getThumbnailUrl());
        } catch (Exception e) {
            addError(e);
        }
        try {
            resultItem.setDescription(extractor.getDescription());
        } catch (Exception e) {
            addError(e);
        }
        return resultItem;
    }
}

package com.baran.baba.yapti.services.peertube;

import java.io.IOException;

import org.jsoup.helper.StringUtil;

import com.baran.baba.yapti.Baba;
import com.baran.baba.yapti.utils.JsonUtils;
import com.baran.baba.yapti.downloader.Downloader;
import com.baran.baba.yapti.downloader.Response;
import com.baran.baba.yapti.exceptions.ParsingException;
import com.baran.baba.yapti.exceptions.ReCaptchaException;

import com.grack.nanojson.JsonObject;
import com.grack.nanojson.JsonParser;
import com.grack.nanojson.JsonParserException;

public class PeertubeInstance {
    
    private final String url;
    private String name;
    public static final PeertubeInstance defaultInstance = new PeertubeInstance("https://framatube.org", "FramaTube");
    
    public PeertubeInstance(String url) {
        this.url = url;
        this.name = "PeerTube";
    }
    
    public PeertubeInstance(String url , String name) {
        this.url = url;
        this.name = name;
    }

    public String getUrl() {
        return url;
    }
    
    public void fetchInstanceMetaData() throws Exception {
        Downloader downloader = Baba.getDownloader();
        Response response = null;
        
        try {
            response = downloader.get(url + "/api/v1/config");
        } catch (ReCaptchaException | IOException e) {
            throw new Exception("unable to configure instance " + url, e);
        }
        
        if(null == response || StringUtil.isBlank(response.responseBody())) {
            throw new Exception("unable to configure instance " + url);
        }
        
         try {
            JsonObject json = JsonParser.object().from(response.responseBody());
            this.name = JsonUtils.getString(json, "instance.name");
        } catch (JsonParserException | ParsingException e) {
            throw new Exception("unable to parse instance config", e);
        }
    }

    public String getName() {
        return name;
    }
    
}

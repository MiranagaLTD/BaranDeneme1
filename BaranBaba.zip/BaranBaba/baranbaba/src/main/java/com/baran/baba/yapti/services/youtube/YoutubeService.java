package com.baran.baba.yapti.services.youtube;

import com.baran.baba.yapti.StreamingService;
import com.baran.baba.yapti.channel.ChannelExtractor;
import com.baran.baba.yapti.comments.CommentsExtractor;
import com.baran.baba.yapti.feed.FeedExtractor;
import com.baran.baba.yapti.kiosk.KioskExtractor;
import com.baran.baba.yapti.kiosk.KioskList;
import com.baran.baba.yapti.search.SearchExtractor;
import com.baran.baba.yapti.services.youtube.extractors.YoutubeChannelExtractor;
import com.baran.baba.yapti.services.youtube.extractors.YoutubeSuggestionExtractor;
import com.baran.baba.yapti.stream.StreamExtractor;
import com.baran.baba.yapti.services.youtube.extractors.YoutubeCommentsExtractor;
import com.baran.baba.yapti.services.youtube.extractors.YoutubeFeedExtractor;
import com.baran.baba.yapti.services.youtube.extractors.YoutubePlaylistExtractor;
import com.baran.baba.yapti.services.youtube.extractors.YoutubeSearchExtractor;
import com.baran.baba.yapti.services.youtube.extractors.YoutubeStreamExtractor;
import com.baran.baba.yapti.services.youtube.extractors.YoutubeSubscriptionExtractor;
import com.baran.baba.yapti.services.youtube.extractors.YoutubeTrendingExtractor;

import static java.util.Arrays.asList;

import java.util.List;

import com.baran.baba.yapti.exceptions.ExtractionException;
import com.baran.baba.yapti.linkhandler.LinkHandler;
import com.baran.baba.yapti.linkhandler.LinkHandlerFactory;
import com.baran.baba.yapti.linkhandler.ListLinkHandler;
import com.baran.baba.yapti.linkhandler.ListLinkHandlerFactory;
import com.baran.baba.yapti.linkhandler.SearchQueryHandler;
import com.baran.baba.yapti.linkhandler.SearchQueryHandlerFactory;
import com.baran.baba.yapti.localization.ContentCountry;
import com.baran.baba.yapti.localization.Localization;
import com.baran.baba.yapti.playlist.PlaylistExtractor;

import org.schabi.newpipe.extractor.services.youtube.extractors.*;
import com.baran.baba.yapti.services.youtube.linkHandler.YoutubeChannelLinkHandlerFactory;
import com.baran.baba.yapti.services.youtube.linkHandler.YoutubeCommentsLinkHandlerFactory;
import com.baran.baba.yapti.services.youtube.linkHandler.YoutubePlaylistLinkHandlerFactory;
import com.baran.baba.yapti.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory;
import com.baran.baba.yapti.services.youtube.linkHandler.YoutubeStreamLinkHandlerFactory;
import com.baran.baba.yapti.services.youtube.linkHandler.YoutubeTrendingLinkHandlerFactory;
import com.baran.baba.yapti.subscription.SubscriptionExtractor;
import com.baran.baba.yapti.suggestion.SuggestionExtractor;

import javax.annotation.Nonnull;


public class YoutubeService extends StreamingService {

    public YoutubeService(int id) {
        super(id, "YouTube", asList(ServiceInfo.MediaCapability.AUDIO, ServiceInfo.MediaCapability.VIDEO, ServiceInfo.MediaCapability.LIVE, ServiceInfo.MediaCapability.COMMENTS));
    }

    @Override
    public String getBaseUrl() {
        return "https://youtube.com";
    }

    @Override
    public LinkHandlerFactory getStreamLHFactory() {
        return YoutubeStreamLinkHandlerFactory.getInstance();
    }

    @Override
    public ListLinkHandlerFactory getChannelLHFactory() {
        return YoutubeChannelLinkHandlerFactory.getInstance();
    }

    @Override
    public ListLinkHandlerFactory getPlaylistLHFactory() {
        return YoutubePlaylistLinkHandlerFactory.getInstance();
    }

    @Override
    public SearchQueryHandlerFactory getSearchQHFactory() {
        return YoutubeSearchQueryHandlerFactory.getInstance();
    }

    @Override
    public StreamExtractor getStreamExtractor(LinkHandler linkHandler) {
        return new YoutubeStreamExtractor(this, linkHandler);
    }

    @Override
    public ChannelExtractor getChannelExtractor(ListLinkHandler linkHandler) {
        return new YoutubeChannelExtractor(this, linkHandler);
    }

    @Override
    public PlaylistExtractor getPlaylistExtractor(ListLinkHandler linkHandler) {
        return new YoutubePlaylistExtractor(this, linkHandler);
    }

    @Override
    public SearchExtractor getSearchExtractor(SearchQueryHandler query) {
        return new YoutubeSearchExtractor(this, query);
    }

    @Override
    public SuggestionExtractor getSuggestionExtractor() {
        return new YoutubeSuggestionExtractor(this);
    }

    @Override
    public KioskList getKioskList() throws ExtractionException {
        KioskList list = new KioskList(this);

        // add kiosks here e.g.:
        try {
            list.addKioskEntry(new KioskList.KioskExtractorFactory() {
                @Override
                public KioskExtractor createNewKiosk(StreamingService streamingService,
                                                     String url,
                                                     String id)
                throws ExtractionException {
                    return new YoutubeTrendingExtractor(YoutubeService.this,
                            new YoutubeTrendingLinkHandlerFactory().fromUrl(url), id);
                }
            }, new YoutubeTrendingLinkHandlerFactory(), "Trending");
            list.setDefaultKiosk("Trending");
        } catch (Exception e) {
            throw new ExtractionException(e);
        }

        return list;
    }

    @Override
    public SubscriptionExtractor getSubscriptionExtractor() {
        return new YoutubeSubscriptionExtractor(this);
    }

    @Nonnull
    @Override
    public FeedExtractor getFeedExtractor(final String channelUrl) throws ExtractionException {
        return new YoutubeFeedExtractor(this, getChannelLHFactory().fromUrl(channelUrl));
    }

    @Override
    public ListLinkHandlerFactory getCommentsLHFactory() {
        return YoutubeCommentsLinkHandlerFactory.getInstance();
    }

    @Override
    public CommentsExtractor getCommentsExtractor(ListLinkHandler urlIdHandler)
            throws ExtractionException {
        return new YoutubeCommentsExtractor(this, urlIdHandler);
    }

    /*//////////////////////////////////////////////////////////////////////////
    // Localization
    //////////////////////////////////////////////////////////////////////////*/

    // https://www.youtube.com/picker_ajax?action_language_json=1
    private static final List<Localization> SUPPORTED_LANGUAGES = Localization.listFrom(
            "en-GB"
            /*"af", "am", "ar", "az", "be", "bg", "bn", "bs", "ca", "cs", "da", "de",
            "el", "en", "en-GB", "es", "es-419", "es-US", "et", "eu", "fa", "fi", "fil", "fr",
            "fr-CA", "gl", "gu", "hi", "hr", "hu", "hy", "id", "is", "it", "iw", "ja",
            "ka", "kk", "km", "kn", "ko", "ky", "lo", "lt", "lv", "mk", "ml", "mn",
            "mr", "ms", "my", "ne", "nl", "no", "pa", "pl", "pt", "pt-PT", "ro", "ru",
            "si", "sk", "sl", "sq", "sr", "sr-Latn", "sv", "sw", "ta", "te", "th", "tr",
            "uk", "ur", "uz", "vi", "zh-CN", "zh-HK", "zh-TW", "zu"*/
    );

    // https://www.youtube.com/picker_ajax?action_country_json=1
    private static final List<ContentCountry> SUPPORTED_COUNTRIES = ContentCountry.listFrom(
            "AD", "AE", "AF", "AG", "AI", "AL", "AM", "AO", "AQ", "AR", "AS", "AT", "AU", "AW", "AX", "AZ", "BA",
            "BB", "BD", "BE", "BF", "BG", "BH", "BI", "BJ", "BL", "BM", "BN", "BO", "BQ", "BR", "BS", "BT", "BV",
            "BW", "BY", "BZ", "CA", "CC", "CD", "CF", "CG", "CH", "CI", "CK", "CL", "CM", "CN", "CO", "CR", "CU",
            "CV", "CW", "CX", "CY", "CZ", "DE", "DJ", "DK", "DM", "DO", "DZ", "EC", "EE", "EG", "EH", "ER", "ES",
            "ET", "FI", "FJ", "FK", "FM", "FO", "FR", "GA", "GB", "GD", "GE", "GF", "GG", "GH", "GI", "GL", "GM",
            "GN", "GP", "GQ", "GR", "GS", "GT", "GU", "GW", "GY", "HK", "HM", "HN", "HR", "HT", "HU", "ID", "IE",
            "IL", "IM", "IN", "IO", "IQ", "IR", "IS", "IT", "JE", "JM", "JO", "JP", "KE", "KG", "KH", "KI", "KM",
            "KN", "KP", "KR", "KW", "KY", "KZ", "LA", "LB", "LC", "LI", "LK", "LR", "LS", "LT", "LU", "LV", "LY",
            "MA", "MC", "MD", "ME", "MF", "MG", "MH", "MK", "ML", "MM", "MN", "MO", "MP", "MQ", "MR", "MS", "MT",
            "MU", "MV", "MW", "MX", "MY", "MZ", "NA", "NC", "NE", "NF", "NG", "NI", "NL", "NO", "NP", "NR", "NU",
            "NZ", "OM", "PA", "PE", "PF", "PG", "PH", "PK", "PL", "PM", "PN", "PR", "PS", "PT", "PW", "PY", "QA",
            "RE", "RO", "RS", "RU", "RW", "SA", "SB", "SC", "SD", "SE", "SG", "SH", "SI", "SJ", "SK", "SL", "SM",
            "SN", "SO", "SR", "SS", "ST", "SV", "SX", "SY", "SZ", "TC", "TD", "TF", "TG", "TH", "TJ", "TK", "TL",
            "TM", "TN", "TO", "TR", "TT", "TV", "TW", "TZ", "UA", "UG", "UM", "US", "UY", "UZ", "VA", "VC", "VE",
            "VG", "VI", "VN", "VU", "WF", "WS", "YE", "YT", "ZA", "ZM", "ZW"
    );

    @Override
    public List<Localization> getSupportedLocalizations() {
        return SUPPORTED_LANGUAGES;
    }

    public List<ContentCountry> getSupportedCountries() {
        return SUPPORTED_COUNTRIES;
    }
}

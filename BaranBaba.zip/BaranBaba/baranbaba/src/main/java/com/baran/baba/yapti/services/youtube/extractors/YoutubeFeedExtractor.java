package com.baran.baba.yapti.services.youtube.extractors;

import com.baran.baba.yapti.ListExtractor;
import com.baran.baba.yapti.StreamingService;
import com.baran.baba.yapti.feed.FeedExtractor;
import com.baran.baba.yapti.stream.StreamInfoItem;
import com.baran.baba.yapti.stream.StreamInfoItemsCollector;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.baran.baba.yapti.downloader.Downloader;
import com.baran.baba.yapti.downloader.Response;
import com.baran.baba.yapti.exceptions.ExtractionException;
import com.baran.baba.yapti.linkhandler.ListLinkHandler;
import com.baran.baba.yapti.services.youtube.linkHandler.YoutubeParsingHelper;

import javax.annotation.Nonnull;
import java.io.IOException;

public class YoutubeFeedExtractor extends FeedExtractor {
    public YoutubeFeedExtractor(StreamingService service, ListLinkHandler linkHandler) {
        super(service, linkHandler);
    }

    private Document document;

    @Override
    public void onFetchPage(@Nonnull Downloader downloader) throws IOException, ExtractionException {
        final String channelIdOrUser = getLinkHandler().getId();
        final String feedUrl = YoutubeParsingHelper.getFeedUrlFrom(channelIdOrUser);

        final Response response = downloader.get(feedUrl);
        document = Jsoup.parse(response.responseBody());
    }

    @Nonnull
    @Override
    public ListExtractor.InfoItemsPage<StreamInfoItem> getInitialPage() {
        final Elements entries = document.select("feed > entry");
        final StreamInfoItemsCollector collector = new StreamInfoItemsCollector(getServiceId());

        for (Element entryElement : entries) {
            collector.commit(new YoutubeFeedInfoItemExtractor(entryElement));
        }

        return new ListExtractor.InfoItemsPage<>(collector, null);
    }

    @Nonnull
    @Override
    public String getId() {
        return document.getElementsByTag("yt:channelId").first().text();
    }

    @Nonnull
    @Override
    public String getUrl() {
        return document.select("feed > author > uri").first().text();
    }

    @Nonnull
    @Override
    public String getName() {
        return document.select("feed > author > name").first().text();
    }

    @Override
    public String getNextPageUrl() {
        return null;
    }

    @Override
    public ListExtractor.InfoItemsPage<StreamInfoItem> getPage(String pageUrl) {
        return null;
    }

    @Override
    public boolean hasNextPage() {
        return false;
    }
}

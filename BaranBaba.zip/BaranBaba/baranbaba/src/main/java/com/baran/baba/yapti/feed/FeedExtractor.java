package com.baran.baba.yapti.feed;

import com.baran.baba.yapti.ListExtractor;
import com.baran.baba.yapti.StreamingService;
import com.baran.baba.yapti.linkhandler.ListLinkHandler;
import com.baran.baba.yapti.stream.StreamInfoItem;

/**
 * This class helps to extract items from lightweight feeds that the services may provide.
 * <p>
 * YouTube is an example of a service that has this alternative available.
 */
public abstract class FeedExtractor extends ListExtractor<StreamInfoItem> {
    public FeedExtractor(StreamingService service, ListLinkHandler listLinkHandler) {
        super(service, listLinkHandler);
    }
}

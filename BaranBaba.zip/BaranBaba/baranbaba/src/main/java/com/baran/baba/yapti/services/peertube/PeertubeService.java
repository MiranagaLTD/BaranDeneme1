package com.baran.baba.yapti.services.peertube;

import com.baran.baba.yapti.StreamingService;
import com.baran.baba.yapti.channel.ChannelExtractor;
import com.baran.baba.yapti.comments.CommentsExtractor;
import com.baran.baba.yapti.kiosk.KioskExtractor;
import com.baran.baba.yapti.kiosk.KioskList;
import com.baran.baba.yapti.playlist.PlaylistExtractor;
import com.baran.baba.yapti.search.SearchExtractor;
import com.baran.baba.yapti.services.peertube.extractors.PeertubeChannelExtractor;
import com.baran.baba.yapti.services.peertube.extractors.PeertubeCommentsExtractor;
import com.baran.baba.yapti.services.peertube.extractors.PeertubeSearchExtractor;
import com.baran.baba.yapti.services.peertube.extractors.PeertubeStreamExtractor;
import com.baran.baba.yapti.services.peertube.extractors.PeertubeSuggestionExtractor;
import com.baran.baba.yapti.services.peertube.extractors.PeertubeTrendingExtractor;
import com.baran.baba.yapti.stream.StreamExtractor;

import static java.util.Arrays.asList;

import com.baran.baba.yapti.exceptions.ExtractionException;
import com.baran.baba.yapti.linkhandler.LinkHandler;
import com.baran.baba.yapti.linkhandler.LinkHandlerFactory;
import com.baran.baba.yapti.linkhandler.ListLinkHandler;
import com.baran.baba.yapti.linkhandler.ListLinkHandlerFactory;
import com.baran.baba.yapti.linkhandler.SearchQueryHandler;
import com.baran.baba.yapti.linkhandler.SearchQueryHandlerFactory;
import com.baran.baba.yapti.services.peertube.linkHandler.PeertubeChannelLinkHandlerFactory;
import com.baran.baba.yapti.services.peertube.linkHandler.PeertubeCommentsLinkHandlerFactory;
import com.baran.baba.yapti.services.peertube.linkHandler.PeertubeSearchQueryHandlerFactory;
import com.baran.baba.yapti.services.peertube.linkHandler.PeertubeStreamLinkHandlerFactory;
import com.baran.baba.yapti.services.peertube.linkHandler.PeertubeTrendingLinkHandlerFactory;
import com.baran.baba.yapti.subscription.SubscriptionExtractor;
import com.baran.baba.yapti.suggestion.SuggestionExtractor;

public class PeertubeService extends StreamingService {
    
    private PeertubeInstance instance;
    
    public PeertubeService(int id) {
        this(id, PeertubeInstance.defaultInstance);
    }
    
    public PeertubeService(int id, PeertubeInstance instance) {
        super(id, "PeerTube", asList(ServiceInfo.MediaCapability.VIDEO, ServiceInfo.MediaCapability.COMMENTS));
        this.instance  = instance;
    }

    @Override
    public LinkHandlerFactory getStreamLHFactory() {
        return PeertubeStreamLinkHandlerFactory.getInstance();
    }

    @Override
    public ListLinkHandlerFactory getChannelLHFactory() {
        return PeertubeChannelLinkHandlerFactory.getInstance();
    }

    @Override
    public ListLinkHandlerFactory getPlaylistLHFactory() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public SearchQueryHandlerFactory getSearchQHFactory() {
        return PeertubeSearchQueryHandlerFactory.getInstance();
    }

    @Override
    public ListLinkHandlerFactory getCommentsLHFactory() {
        return PeertubeCommentsLinkHandlerFactory.getInstance();
    }

    @Override
    public SearchExtractor getSearchExtractor(SearchQueryHandler queryHandler) {
        return new PeertubeSearchExtractor(this, queryHandler);
    }

    @Override
    public SuggestionExtractor getSuggestionExtractor() {
        return new PeertubeSuggestionExtractor(this);
    }

    @Override
    public SubscriptionExtractor getSubscriptionExtractor() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public ChannelExtractor getChannelExtractor(ListLinkHandler linkHandler)
            throws ExtractionException {
        return new PeertubeChannelExtractor(this, linkHandler);
    }

    @Override
    public PlaylistExtractor getPlaylistExtractor(ListLinkHandler linkHandler)
            throws ExtractionException {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public StreamExtractor getStreamExtractor(LinkHandler linkHandler)
            throws ExtractionException {
        return new PeertubeStreamExtractor(this, linkHandler);
    }

    @Override
    public CommentsExtractor getCommentsExtractor(ListLinkHandler linkHandler)
            throws ExtractionException {
        return new PeertubeCommentsExtractor(this, linkHandler);
    }

    @Override
    public String getBaseUrl() {
        return instance.getUrl();
    }
    
    public PeertubeInstance getInstance() {
        return this.instance;
    }
    
    public void setInstance(PeertubeInstance instance) {
        this.instance = instance;
    }
    
    @Override
    public KioskList getKioskList() throws ExtractionException {
        KioskList.KioskExtractorFactory kioskFactory = new KioskList.KioskExtractorFactory() {
            @Override
            public KioskExtractor createNewKiosk(StreamingService streamingService,
                                                 String url,
                                                 String id)
                    throws ExtractionException {
                return new PeertubeTrendingExtractor(PeertubeService.this,
                        new PeertubeTrendingLinkHandlerFactory().fromId(id), id);
            }
        };

        KioskList list = new KioskList(this);

        // add kiosks here e.g.:
        final PeertubeTrendingLinkHandlerFactory h = new PeertubeTrendingLinkHandlerFactory();
        try {
            list.addKioskEntry(kioskFactory, h, PeertubeTrendingLinkHandlerFactory.KIOSK_TRENDING);
            list.addKioskEntry(kioskFactory, h, PeertubeTrendingLinkHandlerFactory.KIOSK_MOST_LIKED);
            list.addKioskEntry(kioskFactory, h, PeertubeTrendingLinkHandlerFactory.KIOSK_RECENT);
            list.addKioskEntry(kioskFactory, h, PeertubeTrendingLinkHandlerFactory.KIOSK_LOCAL);
            list.setDefaultKiosk(PeertubeTrendingLinkHandlerFactory.KIOSK_TRENDING);
        } catch (Exception e) {
            throw new ExtractionException(e);
        }

        return list;
    }
    

}

package com.baran.baba.yapti.search;

import com.baran.baba.yapti.InfoItem;
import com.baran.baba.yapti.ListExtractor;
import com.baran.baba.yapti.StreamingService;
import com.baran.baba.yapti.exceptions.ExtractionException;
import com.baran.baba.yapti.exceptions.ParsingException;
import com.baran.baba.yapti.linkhandler.SearchQueryHandler;

import javax.annotation.Nonnull;

public abstract class SearchExtractor extends ListExtractor<InfoItem> {

    public static class NothingFoundException extends ExtractionException {
        public NothingFoundException(String message) {
            super(message);
        }
    }

    private final InfoItemsSearchCollector collector;

    public SearchExtractor(StreamingService service, SearchQueryHandler linkHandler) {
        super(service, linkHandler);
        collector = new InfoItemsSearchCollector(service.getServiceId());
    }

    public String getSearchString() {
        return getLinkHandler().getSearchString();
    }

    public abstract String getSearchSuggestion() throws ParsingException;

    protected InfoItemsSearchCollector getInfoItemSearchCollector() {
        return collector;
    }

    @Override
    public SearchQueryHandler getLinkHandler() {
        return (SearchQueryHandler) super.getLinkHandler();
    }

    @Nonnull
    @Override
    public String getName() {
        return getLinkHandler().getSearchString();
    }
}

package com.baran.baba.yapti.services.peertube.linkHandler;

import com.baran.baba.yapti.ServiceList;
import com.baran.baba.yapti.utils.Parser;

import java.util.List;

import com.baran.baba.yapti.exceptions.FoundAdException;
import com.baran.baba.yapti.exceptions.ParsingException;
import com.baran.baba.yapti.linkhandler.ListLinkHandlerFactory;

public class PeertubeCommentsLinkHandlerFactory extends ListLinkHandlerFactory {

    private static final PeertubeCommentsLinkHandlerFactory instance = new PeertubeCommentsLinkHandlerFactory();
    private static final String ID_PATTERN = "/videos/(watch/)?([^/?&#]*)";
    private static final String COMMENTS_ENDPOINT = "/api/v1/videos/%s/comment-threads";

    public static PeertubeCommentsLinkHandlerFactory getInstance() {
        return instance;
    }

    @Override
    public String getId(String url) throws ParsingException, IllegalArgumentException {
        return Parser.matchGroup(ID_PATTERN, url, 2);
    }

    @Override
    public boolean onAcceptUrl(final String url) throws FoundAdException {
        return url.contains("/videos/");
    }

    @Override
    public String getUrl(String id, List<String> contentFilter, String sortFilter) throws ParsingException {
        String baseUrl = ServiceList.PeerTube.getBaseUrl();
        return getUrl(id, contentFilter, sortFilter, baseUrl);
    }
    
    @Override
    public String getUrl(String id, List<String> contentFilter, String sortFilter, String baseUrl) throws ParsingException {
        return baseUrl + String.format(COMMENTS_ENDPOINT, id);
    }
   
}

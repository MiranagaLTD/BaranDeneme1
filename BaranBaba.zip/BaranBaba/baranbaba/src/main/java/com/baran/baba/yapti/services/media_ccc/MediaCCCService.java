package com.baran.baba.yapti.services.media_ccc;

import com.baran.baba.yapti.StreamingService;
import com.baran.baba.yapti.channel.ChannelExtractor;
import com.baran.baba.yapti.comments.CommentsExtractor;
import com.baran.baba.yapti.kiosk.KioskExtractor;
import com.baran.baba.yapti.kiosk.KioskList;
import com.baran.baba.yapti.playlist.PlaylistExtractor;
import com.baran.baba.yapti.search.SearchExtractor;
import com.baran.baba.yapti.services.media_ccc.extractors.MediaCCCConferenceExtractor;
import com.baran.baba.yapti.services.media_ccc.extractors.MediaCCCConferenceKiosk;
import com.baran.baba.yapti.services.media_ccc.extractors.MediaCCCSearchExtractor;
import com.baran.baba.yapti.stream.StreamExtractor;
import com.baran.baba.yapti.linkhandler.LinkHandler;
import com.baran.baba.yapti.linkhandler.LinkHandlerFactory;
import com.baran.baba.yapti.linkhandler.ListLinkHandler;
import com.baran.baba.yapti.linkhandler.ListLinkHandlerFactory;
import com.baran.baba.yapti.linkhandler.SearchQueryHandler;
import com.baran.baba.yapti.linkhandler.SearchQueryHandlerFactory;
import com.baran.baba.yapti.exceptions.ExtractionException;

import org.schabi.newpipe.extractor.linkhandler.*;

import com.baran.baba.yapti.services.media_ccc.extractors.MediaCCCStreamExtractor;
import com.baran.baba.yapti.services.media_ccc.linkHandler.MediaCCCConferenceLinkHandlerFactory;
import com.baran.baba.yapti.services.media_ccc.linkHandler.MediaCCCConferencesListLinkHandlerFactory;
import com.baran.baba.yapti.services.media_ccc.linkHandler.MediaCCCSearchQueryHandlerFactory;
import com.baran.baba.yapti.services.media_ccc.linkHandler.MediaCCCStreamLinkHandlerFactory;
import com.baran.baba.yapti.subscription.SubscriptionExtractor;
import com.baran.baba.yapti.suggestion.SuggestionExtractor;

import java.io.IOException;

import static java.util.Arrays.asList;

public class MediaCCCService extends StreamingService {
    public MediaCCCService(int id) {
        super(id, "MediaCCC", asList(ServiceInfo.MediaCapability.AUDIO, ServiceInfo.MediaCapability.VIDEO));
    }

    @Override
    public SearchExtractor getSearchExtractor(SearchQueryHandler query) {
        return new MediaCCCSearchExtractor(this, query);
    }

    @Override
    public LinkHandlerFactory getStreamLHFactory() {
        return new MediaCCCStreamLinkHandlerFactory();
    }

    @Override
    public ListLinkHandlerFactory getChannelLHFactory() {
        return new MediaCCCConferenceLinkHandlerFactory();
    }

    @Override
    public ListLinkHandlerFactory getPlaylistLHFactory() {
        return null;
    }

    @Override
    public SearchQueryHandlerFactory getSearchQHFactory() {
        return new MediaCCCSearchQueryHandlerFactory();
    }

    @Override
    public StreamExtractor getStreamExtractor(LinkHandler linkHandler) {
        return new MediaCCCStreamExtractor(this, linkHandler);
    }

    @Override
    public ChannelExtractor getChannelExtractor(ListLinkHandler linkHandler) {
        return new MediaCCCConferenceExtractor(this, linkHandler);
    }

    @Override
    public PlaylistExtractor getPlaylistExtractor(ListLinkHandler linkHandler) {
        return null;
    }

    @Override
    public SuggestionExtractor getSuggestionExtractor() {
        return null;
    }

    @Override
    public KioskList getKioskList() throws ExtractionException {
        KioskList list = new KioskList(this);

        // add kiosks here e.g.:
        try {
            list.addKioskEntry(new KioskList.KioskExtractorFactory() {
                @Override
                public KioskExtractor createNewKiosk(StreamingService streamingService,
                                                     String url,
                                                     String kioskId) throws ExtractionException, IOException {
                    return new MediaCCCConferenceKiosk(MediaCCCService.this,
                            new MediaCCCConferencesListLinkHandlerFactory().fromUrl(url), kioskId);
                }
            }, new MediaCCCConferencesListLinkHandlerFactory(), "conferences");
            list.setDefaultKiosk("conferences");
        } catch (Exception e) {
            throw new ExtractionException(e);
        }

        return list;
    }

    @Override
    public SubscriptionExtractor getSubscriptionExtractor() {
        return null;
    }

    @Override
    public ListLinkHandlerFactory getCommentsLHFactory() {
        return null;
    }

    @Override
    public CommentsExtractor getCommentsExtractor(ListLinkHandler linkHandler)
            throws ExtractionException {
        return null;
    }

    @Override
    public String getBaseUrl() {
        return "https://media.ccc.de";
    }

}

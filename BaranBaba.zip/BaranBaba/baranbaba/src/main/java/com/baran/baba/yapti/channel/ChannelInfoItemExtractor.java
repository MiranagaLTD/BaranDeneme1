package com.baran.baba.yapti.channel;

import com.baran.baba.yapti.InfoItemExtractor;
import com.baran.baba.yapti.exceptions.ParsingException;


public interface ChannelInfoItemExtractor extends InfoItemExtractor {
    String getDescription() throws ParsingException;

    long getSubscriberCount() throws ParsingException;
    long getStreamCount() throws ParsingException;
}

package com.baran.baba.yapti.services.peertube.linkHandler;

import com.baran.baba.yapti.ServiceList;
import com.baran.baba.yapti.utils.Parser;
import com.baran.baba.yapti.exceptions.FoundAdException;
import com.baran.baba.yapti.exceptions.ParsingException;
import com.baran.baba.yapti.linkhandler.LinkHandlerFactory;

public class PeertubeStreamLinkHandlerFactory extends LinkHandlerFactory {

    private static final PeertubeStreamLinkHandlerFactory instance = new PeertubeStreamLinkHandlerFactory();
    private static final String ID_PATTERN = "/videos/(watch/)?([^/?&#]*)";
    private static final String VIDEO_ENDPOINT = "/api/v1/videos/";

    private PeertubeStreamLinkHandlerFactory() {
    }

    public static PeertubeStreamLinkHandlerFactory getInstance() {
        return instance;
    }

    @Override
    public String getUrl(String id) {
        String baseUrl = ServiceList.PeerTube.getBaseUrl();
        return getUrl(id, baseUrl);
    }
    
    @Override
    public String getUrl(String id, String baseUrl) {
        return baseUrl + VIDEO_ENDPOINT + id;
    }

    @Override
    public String getId(String url) throws ParsingException, IllegalArgumentException {
        return Parser.matchGroup(ID_PATTERN, url, 2);
    }

    @Override
    public boolean onAcceptUrl(final String url) throws FoundAdException {
        return url.contains("/videos/");
    }
}

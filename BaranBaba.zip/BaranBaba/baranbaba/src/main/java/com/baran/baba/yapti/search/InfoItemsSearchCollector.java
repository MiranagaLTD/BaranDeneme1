package com.baran.baba.yapti.search;

import com.baran.baba.yapti.InfoItem;
import com.baran.baba.yapti.InfoItemExtractor;
import com.baran.baba.yapti.InfoItemsCollector;
import com.baran.baba.yapti.stream.StreamInfoItemsCollector;
import com.baran.baba.yapti.channel.ChannelInfoItemExtractor;
import com.baran.baba.yapti.channel.ChannelInfoItemsCollector;
import com.baran.baba.yapti.exceptions.ParsingException;
import com.baran.baba.yapti.playlist.PlaylistInfoItemExtractor;
import com.baran.baba.yapti.playlist.PlaylistInfoItemsCollector;
import com.baran.baba.yapti.stream.StreamInfoItemExtractor;


public class InfoItemsSearchCollector extends InfoItemsCollector<InfoItem, InfoItemExtractor> {
    private final StreamInfoItemsCollector streamCollector;
    private final ChannelInfoItemsCollector userCollector;
    private final PlaylistInfoItemsCollector playlistCollector;

    InfoItemsSearchCollector(int serviceId) {
        super(serviceId);
        streamCollector = new StreamInfoItemsCollector(serviceId);
        userCollector = new ChannelInfoItemsCollector(serviceId);
        playlistCollector = new PlaylistInfoItemsCollector(serviceId);
    }

    @Override
    public InfoItem extract(InfoItemExtractor extractor) throws ParsingException {
        // Use the corresponding collector for each item yapti type
        if(extractor instanceof StreamInfoItemExtractor) {
            return streamCollector.extract((StreamInfoItemExtractor) extractor);
        } else if(extractor instanceof ChannelInfoItemExtractor) {
            return userCollector.extract((ChannelInfoItemExtractor) extractor);
        } else if(extractor instanceof PlaylistInfoItemExtractor) {
            return playlistCollector.extract((PlaylistInfoItemExtractor) extractor);
        } else {
            throw new IllegalArgumentException("Invalid yapti type: " + extractor);
        }
    }
}

package com.baran.baba.yapti.stream;



import com.baran.baba.yapti.Extractor;
import com.baran.baba.yapti.MediaFormat;
import com.baran.baba.yapti.StreamingService;
import com.baran.baba.yapti.exceptions.ExtractionException;
import com.baran.baba.yapti.exceptions.ParsingException;
import com.baran.baba.yapti.linkhandler.LinkHandler;
import com.baran.baba.yapti.localization.DateWrapper;
import com.baran.baba.yapti.utils.Parser;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Scrapes information from a video/audio streaming service (eg, YouTube).
 */
public abstract class StreamExtractor extends Extractor {

    public static final int NO_AGE_LIMIT = 0;

    public StreamExtractor(StreamingService service, LinkHandler linkHandler) {
        super(service, linkHandler);
    }

    /**
     * The original textual date provided by the service. Should be used as a fallback if
     * {@link #getUploadDate()} isn't provided by the service, or it fails for some reason.
     *
     * <p>If the stream is a live stream, {@code null} should be returned.</p>
     *
     * @return The original textual date provided by the service, or {@code null}.
     * @throws ParsingException if there is an error in the extraction
     * @see #getUploadDate()
     */
    @Nullable
    public abstract String getTextualUploadDate() throws ParsingException;

    /**
     * A more general {@code Calendar} instance set to the date provided by the service.<br>
     * Implementations usually will just parse the date returned from the {@link #getTextualUploadDate()}.
     *
     * <p>If the stream is a live stream, {@code null} should be returned.</p>
     *
     * @return The date this item was uploaded, or {@code null}.
     * @throws ParsingException if there is an error in the extraction
     *                          or the extracted date couldn't be parsed.
     * @see #getTextualUploadDate()
     */
    @Nullable
    public abstract DateWrapper getUploadDate() throws ParsingException;

    /**
     * This will return the url to the thumbnail of the stream. Try to return the medium resolution here.
     * @return The url of the thumbnail.
     * @throws ParsingException
     */
    @Nonnull
    public abstract String getThumbnailUrl() throws ParsingException;

    /**
     * This is the stream description.
     * @return The description of the stream/video or Description.emptyDescription if the description is empty.
     * @throws ParsingException
     */
    @Nonnull
    public abstract Description getDescription() throws ParsingException;

    /**
     * Get the age limit.
     * @return The age which limits the content or {@value NO_AGE_LIMIT} if there is no limit
     * @throws ParsingException if an error occurs while parsing
     */
    public abstract int getAgeLimit() throws ParsingException;

    /**
     * This should return the length of a video in seconds.
     * @return The length of the stream in seconds.
     * @throws ParsingException
     */
    public abstract long getLength() throws ParsingException;

    public abstract long getTimeStamp() throws ParsingException;


    public abstract long getViewCount() throws ParsingException;


    public abstract long getLikeCount() throws ParsingException;


    public abstract long getDislikeCount() throws ParsingException;


    @Nonnull
    public abstract String getUploaderUrl() throws ParsingException;


    @Nonnull
    public abstract String getUploaderName() throws ParsingException;


    @Nonnull
    public abstract String getUploaderAvatarUrl() throws ParsingException;


    @Nonnull public abstract String getDashMpdUrl() throws ParsingException;


    @Nonnull public abstract String getHlsUrl() throws ParsingException;

    public abstract List<AudioStream> getAudioStreams() throws IOException, ExtractionException;


    public abstract List<VideoStream> getVideoStreams() throws IOException, ExtractionException;


    public abstract List<VideoStream> getVideoOnlyStreams() throws IOException, ExtractionException;


    @Nonnull
    public abstract List<SubtitlesStream> getSubtitlesDefault() throws IOException, ExtractionException;


    @Nonnull
    public abstract List<SubtitlesStream> getSubtitles(MediaFormat format) throws IOException, ExtractionException;


    public abstract StreamType getStreamType() throws ParsingException;


    public abstract StreamInfoItem getNextStream() throws IOException, ExtractionException;

    /**
     * Should return a list of streams related to the current handled. Many services show suggested
     * streams. If you don't like suggested streams you should implement them anyway since they can
     * be disabled by the user later in the frontend.
     * This list MUST NOT contain the next available video as this should be return through getNextStream()
     * If  is is not available simply return null
     * @return a list of InfoItems showing the related videos/streams
     * @throws IOException
     * @throws ExtractionException
     */
    public abstract StreamInfoItemsCollector getRelatedStreams() throws IOException, ExtractionException;

    /**
     * Should return a list of Frameset object that contains preview of stream frames
     * @return list of preview frames or empty list if frames preview is not supported or not found for specified stream
     * @throws IOException
     * @throws ExtractionException
     */
    @Nonnull
    public List<Frameset> getFrames() throws IOException, ExtractionException {
        return Collections.emptyList();
    }

    /**
     * Should analyse the webpage's document and extracts any error message there might be.
     *
     * @return Error message; null if there is no error message.
     */
    public abstract String getErrorMessage();

    //////////////////////////////////////////////////////////////////
    ///  Helper
    //////////////////////////////////////////////////////////////////

    /**
     * Override this function if the format of time stamp in the url is not the same format as that form youtube.
     * Honestly I don't even know the time stamp fromat of youtube.
     * @param regexPattern
     * @return the sime stamp/seek for the video in seconds
     * @throws ParsingException
     */
    protected long getTimestampSeconds(String regexPattern) throws ParsingException {
        String timeStamp;
        try {
            timeStamp = Parser.matchGroup1(regexPattern, getOriginalUrl());
        } catch (Parser.RegexException e) {
            // catch this instantly since an url does not necessarily have to have a time stamp

            // -2 because well the testing system will then know its the regex that failed :/
            // not good i know
            return -2;
        }

        if (!timeStamp.isEmpty()) {
            try {
                String secondsString = "";
                String minutesString = "";
                String hoursString = "";
                try {
                    secondsString = Parser.matchGroup1("(\\d{1,3})s", timeStamp);
                    minutesString = Parser.matchGroup1("(\\d{1,3})m", timeStamp);
                    hoursString = Parser.matchGroup1("(\\d{1,3})h", timeStamp);
                } catch (Exception e) {
                    //it could be that time is given in another method
                    if (secondsString.isEmpty() //if nothing was got,
                            && minutesString.isEmpty()//treat as unlabelled seconds
                            && hoursString.isEmpty()) {
                        secondsString = Parser.matchGroup1("t=(\\d+)", timeStamp);
                    }
                }

                int seconds = secondsString.isEmpty() ? 0 : Integer.parseInt(secondsString);
                int minutes = minutesString.isEmpty() ? 0 : Integer.parseInt(minutesString);
                int hours = hoursString.isEmpty() ? 0 : Integer.parseInt(hoursString);

                //don't trust BODMAS!
                return seconds + (60 * minutes) + (3600 * hours);
                //Log.d(TAG, "derived timestamp value:"+ret);
                //the ordering varies internationally
            } catch (ParsingException e) {
                throw new ParsingException("Could not get timestamp.", e);
            }
        } else {
            return 0;
        }
    }

    /**
     * The host of the stream (Eg. peertube.cpy.re).
     * If the host is not available, or if the service doesn't use
     * a federated system, but a centralised system,
     * you can simply return an empty string.
     * @return the host of the stream or an empty String.
     * @throws ParsingException
     */
    @Nonnull
    public abstract String getHost() throws ParsingException;

    /**
     * The privacy of the stream (Eg. Public, Private, Unlisted…).
     * If the privacy is not available you can simply return an empty string.
     * @return the privacy of the stream or an empty String.
     * @throws ParsingException
     */
    @Nonnull
    public abstract String getPrivacy() throws ParsingException;

    /**
     * The name of the category of the stream.
     * If the category is not available you can simply return an empty string.
     * @return the category of the stream or an empty String.
     * @throws ParsingException
     */
    @Nonnull
    public abstract String getCategory() throws ParsingException;

    /**
     * The name of the licence of the stream.
     * If the licence is not available you can simply return an empty string.
     * @return the licence of the stream or an empty String.
     * @throws ParsingException
     */
    @Nonnull
    public abstract String getLicence() throws ParsingException;

    /**
     * The locale language of the stream.
     * If the language is not available you can simply return null.
     * If the language is provided by a language code, you can return
     * new Locale(language_code);
     * @return the locale language of the stream or null.
     * @throws ParsingException
     */
    @Nullable
    public abstract Locale getLanguageInfo() throws ParsingException;

    /**
     * The list of tags of the stream.
     * If the tag list is not available you can simply return an empty list.
     * @return the list of tags of the stream or an empty list.
     * @throws ParsingException
     */
    @Nonnull
    public abstract List<String> getTags() throws ParsingException;

    /**
     * The support information of the stream.
     * see: https://framatube.org/videos/watch/ee408ec8-07cd-4e35-b884-fb681a4b9d37
     * (support button).
     * If the support information are not available,
     * you can simply return an empty String.
     * @return the support information of the stream or an empty String.
     * @throws ParsingException
     */
    @Nonnull
    public abstract String getSupportInfo() throws ParsingException;
}

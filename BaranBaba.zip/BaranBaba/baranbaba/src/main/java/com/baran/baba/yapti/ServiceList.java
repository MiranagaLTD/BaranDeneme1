package com.baran.baba.yapti;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.baran.baba.yapti.services.media_ccc.MediaCCCService;
import com.baran.baba.yapti.services.peertube.PeertubeService;
import com.baran.baba.yapti.services.soundcloud.SoundcloudService;
import com.baran.baba.yapti.services.youtube.YoutubeService;

public final class ServiceList {
    private ServiceList() {
        //no instance
    }

    public static final YoutubeService YouTube;
    public static final SoundcloudService SoundCloud;
    public static final MediaCCCService MediaCCC;
    public static final PeertubeService PeerTube;

    /**
     * When creating a new service, put this service in the end of this list,
     * and give it the next free id.
     */
    private static final List<StreamingService> SERVICES = Collections.unmodifiableList(
            Arrays.asList(
                    YouTube = new YoutubeService(0),
                    SoundCloud = new SoundcloudService(1),
                    MediaCCC = new MediaCCCService(2),
                    PeerTube = new PeertubeService(3)
            ));

    /**
     * Get all the supported services.
     *
     * @return a unmodifiable list of all the supported services
     */
    public static List<StreamingService> all() {
        return SERVICES;
    }
}

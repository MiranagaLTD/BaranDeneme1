package com.baran.baba.yapti.services.peertube.extractors;

import com.baran.baba.yapti.StreamingService;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

import com.baran.baba.yapti.exceptions.ExtractionException;
import com.baran.baba.yapti.suggestion.SuggestionExtractor;

public class PeertubeSuggestionExtractor extends SuggestionExtractor{

    public PeertubeSuggestionExtractor(StreamingService service) {
        super(service);
    }

    @Override
    public List<String> suggestionList(String query) throws IOException, ExtractionException {
        return Collections.emptyList();
    }

}

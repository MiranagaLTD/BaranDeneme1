package com.baran.baba.yapti.exceptions;

public class FoundAdException extends ParsingException {
    public FoundAdException(String message) {
        super(message);
    }

    public FoundAdException(String message, Throwable cause) {
        super(message, cause);
    }
}

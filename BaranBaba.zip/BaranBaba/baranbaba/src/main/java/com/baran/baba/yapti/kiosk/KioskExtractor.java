package com.baran.baba.yapti.kiosk;


import com.baran.baba.yapti.InfoItem;
import com.baran.baba.yapti.ListExtractor;
import com.baran.baba.yapti.StreamingService;
import com.baran.baba.yapti.exceptions.ParsingException;
import com.baran.baba.yapti.linkhandler.ListLinkHandler;

import javax.annotation.Nonnull;

public abstract class KioskExtractor<T extends InfoItem> extends ListExtractor<T> {
    private final String id;

    public KioskExtractor(StreamingService streamingService,
                          ListLinkHandler linkHandler,
                          String kioskId) {
        super(streamingService, linkHandler);
        this.id = kioskId;
    }

    @Nonnull
    @Override
    public String getId() {
        return id;
    }

    /**
     * Id should be the name of the kiosk, tho Id is used for identifing it in the frontend,
     * so id should be kept in english.
     * In order to get the name of the kiosk in the desired language we have to
     * crawl if from the website.
     * @return the tranlsated version of id
     * @throws ParsingException
     */
    @Nonnull
    @Override
    public abstract String getName() throws ParsingException;
}

package com.baran.baba.yapti.services.peertube.extractors;

import com.baran.baba.yapti.StreamingService;

import java.util.List;

import com.baran.baba.yapti.subscription.SubscriptionExtractor;

public class PeertubeSubscriptionExtractor extends SubscriptionExtractor {

    public PeertubeSubscriptionExtractor(StreamingService service, List<ContentSource> supportedSources) {
        super(service, supportedSources);
        // TODO Auto-generated constructor stub
    }

    @Override
    public String getRelatedUrl() {
        // TODO Auto-generated method stub
        return null;
    }

}

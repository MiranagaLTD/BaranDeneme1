package com.baran.baba.yapti.comments;

import com.baran.baba.yapti.ListExtractor;
import com.baran.baba.yapti.StreamingService;
import com.baran.baba.yapti.linkhandler.ListLinkHandler;

public abstract class CommentsExtractor extends ListExtractor<CommentsInfoItem> {

    public CommentsExtractor(StreamingService service, ListLinkHandler uiHandler) {
        super(service, uiHandler);
        // TODO Auto-generated constructor stub
    }

}

package com.baran.baba.yapti.comments;

import com.baran.baba.yapti.InfoItemExtractor;
import com.baran.baba.yapti.exceptions.ParsingException;
import com.baran.baba.yapti.localization.DateWrapper;

import javax.annotation.Nullable;

public interface CommentsInfoItemExtractor extends InfoItemExtractor {
    String getCommentId() throws ParsingException;
    String getCommentText() throws ParsingException;
    String getAuthorName() throws ParsingException;
    String getAuthorThumbnail() throws ParsingException;
    String getAuthorEndpoint() throws ParsingException;
    String getTextualPublishedTime() throws ParsingException;
    @Nullable
    DateWrapper getPublishedTime() throws ParsingException;
    int getLikeCount() throws ParsingException;
}

package com.schabi.newpipe.extractor.services.peertube;

import com.schabi.newpipe.DownloaderTestImpl;
import com.baran.baba.yapti.Baba;
import com.baran.baba.yapti.exceptions.ParsingException;
import com.baran.baba.yapti.services.peertube.linkHandler.PeertubeCommentsLinkHandlerFactory;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * Test for {@link PeertubeCommentsLinkHandlerFactory}
 */
public class PeertubeCommentsLinkHandlerFactoryTest {

    private static PeertubeCommentsLinkHandlerFactory linkHandler;

    @BeforeClass
    public static void setUp() {
        linkHandler = PeertubeCommentsLinkHandlerFactory.getInstance();
        Baba.init(DownloaderTestImpl.getInstance());
    }

    @Test
    public void acceptUrlTest() throws ParsingException {
        assertTrue(linkHandler.acceptUrl("https://peertube.mastodon.host/api/v1/videos/19319/comment-threads?start=0&count=10&sort=-createdAt"));
    }

    @Test
    public void getIdFromUrl() throws ParsingException {
        Assert.assertEquals("19319", linkHandler.fromUrl("https://peertube.mastodon.host/api/v1/videos/19319/comment-threads").getId());
        Assert.assertEquals("19319", linkHandler.fromUrl("https://peertube.mastodon.host/api/v1/videos/19319/comment-threads?start=0&count=10&sort=-createdAt").getId());
    }
}

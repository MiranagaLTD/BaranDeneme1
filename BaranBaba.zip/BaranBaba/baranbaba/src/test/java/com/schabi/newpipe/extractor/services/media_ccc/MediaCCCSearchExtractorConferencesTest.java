package com.schabi.newpipe.extractor.services.media_ccc;

import com.schabi.newpipe.DownloaderTestImpl;
import com.baran.baba.yapti.InfoItem;
import com.baran.baba.yapti.ListExtractor;
import com.baran.baba.yapti.Baba;
import com.baran.baba.yapti.ServiceList;
import com.baran.baba.yapti.channel.ChannelInfoItem;
import com.baran.baba.yapti.search.SearchExtractor;
import com.baran.baba.yapti.services.media_ccc.extractors.MediaCCCSearchExtractor;
import com.baran.baba.yapti.services.media_ccc.linkHandler.MediaCCCSearchQueryHandlerFactory;

import org.junit.BeforeClass;
import org.junit.Test;

import java.util.Arrays;

import static junit.framework.TestCase.assertTrue;

/**
 * Test for {@link MediaCCCSearchExtractor}
 */
public class MediaCCCSearchExtractorConferencesTest {

    private static SearchExtractor extractor;
    private static ListExtractor.InfoItemsPage<InfoItem> itemsPage;

    @BeforeClass
    public static void setUpClass() throws Exception {
        Baba.init(DownloaderTestImpl.getInstance());
        extractor =  ServiceList.MediaCCC.getSearchExtractor( new MediaCCCSearchQueryHandlerFactory()
                .fromQuery("c3", Arrays.asList(new String[]{"conferences"}), ""));
        extractor.fetchPage();
        itemsPage = extractor.getInitialPage();
    }

    @Test
    public void testReturnTypeChannel() {
        for(InfoItem item : itemsPage.getItems()) {
            assertTrue("Item is not of type channel", item instanceof ChannelInfoItem);
        }
    }

    @Test
    public void testItemCount() {
        assertTrue("Count is to hight: " + itemsPage.getItems().size(), itemsPage.getItems().size() < 127);
        assertTrue("Countis to low: " + itemsPage.getItems().size(), itemsPage.getItems().size() >= 29);
    }
}

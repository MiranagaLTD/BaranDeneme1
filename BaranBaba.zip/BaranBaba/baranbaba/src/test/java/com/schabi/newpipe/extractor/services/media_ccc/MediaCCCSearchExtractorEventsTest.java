package com.schabi.newpipe.extractor.services.media_ccc;

import com.schabi.newpipe.DownloaderTestImpl;
import com.baran.baba.yapti.InfoItem;
import com.baran.baba.yapti.ListExtractor;
import com.baran.baba.yapti.Baba;
import com.baran.baba.yapti.ServiceList;
import com.baran.baba.yapti.search.SearchExtractor;
import com.baran.baba.yapti.services.media_ccc.extractors.MediaCCCSearchExtractor;
import com.baran.baba.yapti.services.media_ccc.linkHandler.MediaCCCSearchQueryHandlerFactory;
import com.baran.baba.yapti.stream.StreamInfoItem;

import junit.framework.TestCase;

import org.junit.BeforeClass;
import org.junit.Test;

import java.util.Arrays;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertFalse;

/**
 * Test for {@link MediaCCCSearchExtractor}
 */
public class MediaCCCSearchExtractorEventsTest {
    private static SearchExtractor extractor;
    private static ListExtractor.InfoItemsPage<InfoItem> itemsPage;

    @BeforeClass
    public static void setUpClass() throws Exception {
        Baba.init(DownloaderTestImpl.getInstance());
        extractor =  ServiceList.MediaCCC.getSearchExtractor( new MediaCCCSearchQueryHandlerFactory()
                .fromQuery("linux", Arrays.asList(new String[]{"events"}), ""));
        extractor.fetchPage();
        itemsPage = extractor.getInitialPage();
    }

    @Test
    public void testCount() throws Exception {
        assertTrue(Integer.toString(itemsPage.getItems().size()),
                itemsPage.getItems().size() >= 25);
    }

    @Test
    public void testServiceId() throws Exception {
        TestCase.assertEquals(2, extractor.getServiceId());
    }

    @Test
    public void testName() throws Exception {
        assertFalse(itemsPage.getItems().get(0).getName(), itemsPage.getItems().get(0).getName().isEmpty());
    }

    @Test
    public void testUrl() throws Exception {
        assertTrue("Url should start with: https://api.media.ccc.de/public/events/",
                itemsPage.getItems().get(0).getUrl().startsWith("https://api.media.ccc.de/public/events/"));
    }

    @Test
    public void testThumbnailUrl() throws Exception {
        assertTrue(itemsPage.getItems().get(0).getThumbnailUrl(),
                itemsPage.getItems().get(0).getThumbnailUrl().startsWith("https://static.media.ccc.de/media/")
                && itemsPage.getItems().get(0).getThumbnailUrl().endsWith(".jpg"));
    }

    @Test
    public void testReturnTypeStream() throws Exception {
        for(InfoItem item : itemsPage.getItems()) {
            assertTrue("Item is not of type StreamInfoItem", item instanceof StreamInfoItem);
        }
    }
}

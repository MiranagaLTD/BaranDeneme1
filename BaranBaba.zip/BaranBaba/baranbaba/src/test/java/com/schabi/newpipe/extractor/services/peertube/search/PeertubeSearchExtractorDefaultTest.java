package com.schabi.newpipe.extractor.services.peertube.search;

import com.schabi.newpipe.DownloaderTestImpl;
import com.baran.baba.yapti.InfoItem;
import com.baran.baba.yapti.ListExtractor;
import com.baran.baba.yapti.Baba;
import com.baran.baba.yapti.ServiceList;
import com.baran.baba.yapti.services.peertube.PeertubeInstance;
import com.baran.baba.yapti.services.peertube.extractors.PeertubeSearchExtractor;
import com.baran.baba.yapti.stream.StreamInfoItem;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Test;

/**
 * Test for {@link PeertubeSearchExtractor}
 */
public class PeertubeSearchExtractorDefaultTest extends PeertubeSearchExtractorBaseTest {

    @BeforeClass
    public static void setUpClass() throws Exception {
        Baba.init(DownloaderTestImpl.getInstance());
        // setting instance might break test when running in parallel
        ServiceList.PeerTube.setInstance(new PeertubeInstance("https://peertube.mastodon.host", "PeerTube on Mastodon.host"));
        extractor = (PeertubeSearchExtractor) ServiceList.PeerTube.getSearchExtractor("kde");
        extractor.fetchPage();
        itemsPage = extractor.getInitialPage();
    }

    @Test
    public void testGetSecondPageUrl() throws Exception {
        assertEquals("https://peertube.mastodon.host/api/v1/search/videos?search=kde&start=12&count=12", extractor.getNextPageUrl());
    }

    @Test
    public void testResultList_FirstElement() {
        InfoItem firstInfoItem = itemsPage.getItems().get(0);
        
        assertTrue("search does not match", firstInfoItem.getName().toLowerCase().contains("kde"));
    }

    @Test
    public void testResultListCheckIfContainsStreamItems() {
        boolean hasStreams = false;
        for(InfoItem item : itemsPage.getItems()) {
            if(item instanceof StreamInfoItem) {
                hasStreams = true;
            }
        }
        assertTrue("Has no InfoItemStreams", hasStreams);
    }

    @Test
    public void testGetSecondPage() throws Exception {
        extractor = (PeertubeSearchExtractor) ServiceList.PeerTube.getSearchExtractor("internet");
        itemsPage = extractor.getInitialPage();
        PeertubeSearchExtractor secondExtractor =
                (PeertubeSearchExtractor) ServiceList.PeerTube.getSearchExtractor("internet");
        ListExtractor.InfoItemsPage<InfoItem> secondPage = secondExtractor.getPage(itemsPage.getNextPageUrl());
        assertTrue(Integer.toString(secondPage.getItems().size()),
                secondPage.getItems().size() >= 10);

        // check if its the same result
        boolean equals = true;
        for (int i = 0; i < secondPage.getItems().size()
                && i < itemsPage.getItems().size(); i++) {
            if(!secondPage.getItems().get(i).getUrl().equals(
                    itemsPage.getItems().get(i).getUrl())) {
                equals = false;
            }
        }
        assertFalse("First and second page are equal", equals);

        assertEquals("https://peertube.mastodon.host/api/v1/search/videos?search=internet&start=24&count=12",
                     secondPage.getNextPageUrl());
    }


    @Test
    public void testId() throws Exception {
        assertEquals("kde", extractor.getId());
    }

    @Test
    public void testName() {
        assertEquals("kde", extractor.getName());
    }
}

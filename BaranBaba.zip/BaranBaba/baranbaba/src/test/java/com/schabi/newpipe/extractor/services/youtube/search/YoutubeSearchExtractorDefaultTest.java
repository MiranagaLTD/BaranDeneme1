package com.schabi.newpipe.extractor.services.youtube.search;

import com.schabi.newpipe.DownloaderTestImpl;
import com.baran.baba.yapti.InfoItem;
import com.baran.baba.yapti.ListExtractor;
import com.baran.baba.yapti.Baba;
import com.baran.baba.yapti.ServiceList;
import com.baran.baba.yapti.channel.ChannelInfoItem;
import com.baran.baba.yapti.services.youtube.extractors.YoutubeSearchExtractor;
import com.baran.baba.yapti.stream.StreamInfoItem;

import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;

public class YoutubeSearchExtractorDefaultTest extends YoutubeSearchExtractorBaseTest {

    @BeforeClass
    public static void setUpClass() throws Exception {
        Baba.init(DownloaderTestImpl.getInstance());
        extractor = (YoutubeSearchExtractor) ServiceList.YouTube.getSearchExtractor("pewdiepie");
        extractor.fetchPage();
        itemsPage = extractor.getInitialPage();
    }

    @Test
    public void testGetUrl() throws Exception {
        assertEquals("https://www.youtube.com/results?q=pewdiepie&gl=GB", extractor.getUrl());
    }


    @Test
    public void testGetSecondPageUrl() throws Exception {
        assertEquals("https://www.youtube.com/results?q=pewdiepie&gl=GB&page=2", extractor.getNextPageUrl());
    }

    @Test
    public void testResultList_FirstElement() {
        InfoItem firstInfoItem = itemsPage.getItems().get(0);
        InfoItem secondInfoItem = itemsPage.getItems().get(1);

        InfoItem channelItem = firstInfoItem instanceof ChannelInfoItem ? firstInfoItem
                : secondInfoItem;

        // The channel should be the first item
        assertTrue((firstInfoItem instanceof ChannelInfoItem)
                || (secondInfoItem instanceof ChannelInfoItem));
        assertEquals("name", "PewDiePie", channelItem.getName());
        assertEquals("url", "https://www.youtube.com/channel/UC-lHJZR3Gqxm24_Vd_AJ5Yw", channelItem.getUrl());
    }

    @Test
    public void testResultListCheckIfContainsStreamItems() {
        boolean hasStreams = false;
        for(InfoItem item : itemsPage.getItems()) {
            if(item instanceof StreamInfoItem) {
                hasStreams = true;
            }
        }
        assertTrue("Has no InfoItemStreams", hasStreams);
    }

    @Test
    public void testGetSecondPage() throws Exception {
        YoutubeSearchExtractor secondExtractor =
                (YoutubeSearchExtractor) ServiceList.YouTube.getSearchExtractor("pewdiepie");
        ListExtractor.InfoItemsPage<InfoItem> secondPage = secondExtractor.getPage(itemsPage.getNextPageUrl());
        assertTrue(Integer.toString(secondPage.getItems().size()),
                secondPage.getItems().size() > 10);

        // check if its the same result
        boolean equals = true;
        for (int i = 0; i < secondPage.getItems().size()
                && i < itemsPage.getItems().size(); i++) {
            if(!secondPage.getItems().get(i).getUrl().equals(
                    itemsPage.getItems().get(i).getUrl())) {
                equals = false;
            }
        }
        assertFalse("First and second page are equal", equals);

        assertEquals("https://www.youtube.com/results?q=pewdiepie&gl=GB&page=3", secondPage.getNextPageUrl());
    }

    @Test
    public void testSuggestionNotNull() throws Exception {
        //todo write a real test
        assertTrue(extractor.getSearchSuggestion() != null);
    }


    @Test
    public void testId() throws Exception {
        assertEquals("pewdiepie", extractor.getId());
    }

    @Test
    public void testName() {
        assertEquals("pewdiepie", extractor.getName());
    }
}

package com.schabi.newpipe.extractor.services.peertube.search;

import com.baran.baba.yapti.ServiceList;
import com.baran.baba.yapti.services.peertube.PeertubeInstance;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

public class PeertubeSearchQHTest {
    
    @BeforeClass
    public static void setUpClass() throws Exception {
        // setting instance might break test when running in parallel
        ServiceList.PeerTube.setInstance(new PeertubeInstance("https://peertube.mastodon.host", "PeerTube on Mastodon.host"));
    }

    @Test
    public void testRegularValues() throws Exception {
        Assert.assertEquals("https://peertube.mastodon.host/api/v1/search/videos?search=asdf", ServiceList.PeerTube.getSearchQHFactory().fromQuery("asdf").getUrl());
        Assert.assertEquals("https://peertube.mastodon.host/api/v1/search/videos?search=hans", ServiceList.PeerTube.getSearchQHFactory().fromQuery("hans").getUrl());
        Assert.assertEquals("https://peertube.mastodon.host/api/v1/search/videos?search=Poifj%26jaijf", ServiceList.PeerTube.getSearchQHFactory().fromQuery("Poifj&jaijf").getUrl());
        Assert.assertEquals("https://peertube.mastodon.host/api/v1/search/videos?search=G%C3%BCl%C3%BCm", ServiceList.PeerTube.getSearchQHFactory().fromQuery("Gülüm").getUrl());
        Assert.assertEquals("https://peertube.mastodon.host/api/v1/search/videos?search=%3Fj%24%29H%C2%A7B", ServiceList.PeerTube.getSearchQHFactory().fromQuery("?j$)H§B").getUrl());
    }
}
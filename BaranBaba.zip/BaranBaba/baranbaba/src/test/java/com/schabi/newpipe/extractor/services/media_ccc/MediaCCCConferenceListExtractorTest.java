package com.schabi.newpipe.extractor.services.media_ccc;

import com.schabi.newpipe.DownloaderTestImpl;
import com.baran.baba.yapti.InfoItem;
import com.baran.baba.yapti.Baba;
import com.baran.baba.yapti.ServiceList;
import com.baran.baba.yapti.kiosk.KioskExtractor;
import com.baran.baba.yapti.services.media_ccc.extractors.MediaCCCConferenceKiosk;

import org.junit.BeforeClass;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertTrue;


/**
 * Test {@link MediaCCCConferenceKiosk}
 */
public class MediaCCCConferenceListExtractorTest {

    private static KioskExtractor extractor;

    @BeforeClass
    public static void setUpClass() throws Exception {
        Baba.init(DownloaderTestImpl.getInstance());
        extractor =  ServiceList.MediaCCC.getKioskList().getDefaultKioskExtractor();
        extractor.fetchPage();
    }

    @Test
    public void getConferencesListTest() throws Exception {
        assertTrue("returned list was to small",
                extractor.getInitialPage().getItems().size() >= 174);
    }

    @Test
    public void conferenceTypeTest() throws Exception {
        assertTrue(contains(extractor.getInitialPage().getItems(), "FrOSCon 2016"));
        assertTrue(contains(extractor.getInitialPage().getItems(), "ChaosWest @ 35c3"));
        assertTrue(contains(extractor.getInitialPage().getItems(), "CTreffOS chaOStalks"));
        assertTrue(contains(extractor.getInitialPage().getItems(), "Datenspuren 2015"));
        assertTrue(contains(extractor.getInitialPage().getItems(), "Chaos Singularity 2017"));
        assertTrue(contains(extractor.getInitialPage().getItems(), "SIGINT10"));
        assertTrue(contains(extractor.getInitialPage().getItems(), "Vintage Computing Festival Berlin 2015"));
        assertTrue(contains(extractor.getInitialPage().getItems(), "FIfFKon 2015"));
        assertTrue(contains(extractor.getInitialPage().getItems(), "33C3: trailers"));
        assertTrue(contains(extractor.getInitialPage().getItems(), "Blinkenlights"));
    }

    private boolean contains(List<InfoItem> itemList, String name) {
        for(InfoItem item : itemList) {
            if(item.getName().equals(name))
                return true;
        }
        return false;
    }
}

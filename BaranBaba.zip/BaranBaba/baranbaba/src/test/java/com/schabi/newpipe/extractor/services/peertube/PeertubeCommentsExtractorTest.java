package com.schabi.newpipe.extractor.services.peertube;

import com.schabi.newpipe.DownloaderTestImpl;
import com.baran.baba.yapti.ListExtractor;
import com.baran.baba.yapti.Baba;
import com.baran.baba.yapti.ServiceList;
import com.baran.baba.yapti.comments.CommentsInfo;
import com.baran.baba.yapti.comments.CommentsInfoItem;
import com.baran.baba.yapti.exceptions.ExtractionException;
import com.baran.baba.yapti.services.peertube.extractors.PeertubeCommentsExtractor;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.List;

import org.jsoup.helper.StringUtil;
import org.junit.BeforeClass;
import org.junit.Test;

public class PeertubeCommentsExtractorTest {

    private static PeertubeCommentsExtractor extractor;

    @BeforeClass
    public static void setUp() throws Exception {
        Baba.init(DownloaderTestImpl.getInstance());
        extractor = (PeertubeCommentsExtractor) ServiceList.PeerTube
                .getCommentsExtractor("https://framatube.org/videos/watch/04af977f-4201-4697-be67-a8d8cae6fa7a");
    }

    @Test
    public void testGetComments() throws IOException, ExtractionException {
        boolean result = false;
        ListExtractor.InfoItemsPage<CommentsInfoItem> comments = extractor.getInitialPage();
        result = findInComments(comments, "@root A great documentary on a great guy.");

        while (comments.hasNextPage() && !result) {
            comments = extractor.getPage(comments.getNextPageUrl());
            result = findInComments(comments, "@root A great documentary on a great guy.");
        }

        assertTrue(result);
    }

    @Test
    public void testGetCommentsFromCommentsInfo() throws IOException, ExtractionException {
        boolean result = false;
        CommentsInfo commentsInfo = CommentsInfo.getInfo("https://framatube.org/videos/watch/a8ea95b8-0396-49a6-8f30-e25e25fb2828");
        assertTrue("Comments".equals(commentsInfo.getName()));
        result = findInComments(commentsInfo.getRelatedItems(), "Loved it!!!");

        String nextPage = commentsInfo.getNextPageUrl();
        while (!StringUtil.isBlank(nextPage) && !result) {
            ListExtractor.InfoItemsPage<CommentsInfoItem> moreItems = CommentsInfo.getMoreItems(ServiceList.PeerTube, commentsInfo, nextPage);
            result = findInComments(moreItems.getItems(), "Loved it!!!");
            nextPage = moreItems.getNextPageUrl();
        }

        assertTrue(result);
    }
    
    @Test
    public void testGetCommentsAllData() throws IOException, ExtractionException {
        ListExtractor.InfoItemsPage<CommentsInfoItem> comments = extractor.getInitialPage();
        for(CommentsInfoItem c: comments.getItems()) {
            assertFalse(StringUtil.isBlank(c.getAuthorEndpoint()));
            assertFalse(StringUtil.isBlank(c.getAuthorName()));
            assertFalse(StringUtil.isBlank(c.getAuthorThumbnail()));
            assertFalse(StringUtil.isBlank(c.getCommentId()));
            assertFalse(StringUtil.isBlank(c.getCommentText()));
            assertFalse(StringUtil.isBlank(c.getName()));
            assertFalse(StringUtil.isBlank(c.getTextualPublishedTime()));
            assertFalse(StringUtil.isBlank(c.getThumbnailUrl()));
            assertFalse(StringUtil.isBlank(c.getUrl()));
            assertFalse(c.getLikeCount() != -1);
        }
    }

    private boolean findInComments(ListExtractor.InfoItemsPage<CommentsInfoItem> comments, String comment) {
        return findInComments(comments.getItems(), comment);
    }

    private boolean findInComments(List<CommentsInfoItem> comments, String comment) {
        for(CommentsInfoItem c: comments) {
            if(c.getCommentText().contains(comment)) {
                return true;
            }
        }
        return false;
    }
}

package com.schabi.newpipe.extractor.services.youtube;



import com.schabi.newpipe.DownloaderTestImpl;
import com.schabi.newpipe.extractor.ExtractorAsserts;
import com.baran.baba.yapti.ListExtractor;
import com.baran.baba.yapti.Baba;
import com.baran.baba.yapti.ServiceList;
import com.baran.baba.yapti.localization.ContentCountry;
import com.baran.baba.yapti.services.youtube.extractors.YoutubeTrendingExtractor;
import com.baran.baba.yapti.services.youtube.linkHandler.YoutubeTrendingLinkHandlerFactory;
import com.baran.baba.yapti.stream.StreamInfoItem;
import com.baran.baba.yapti.utils.Utils;

import junit.framework.TestCase;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import static junit.framework.TestCase.assertFalse;
import static org.junit.Assert.*;


/**
 * Test for {@link YoutubeTrendingLinkHandlerFactory}
 */
public class YoutubeTrendingExtractorTest {

    static YoutubeTrendingExtractor extractor;

    @BeforeClass
    public static void setUp() throws Exception {
        Baba.init(DownloaderTestImpl.getInstance());
        extractor = (YoutubeTrendingExtractor) ServiceList.YouTube
                .getKioskList()
                .getExtractorById("Trending", null);
        extractor.forceContentCountry(new ContentCountry("de"));
        extractor.fetchPage();
    }

    @Test
    public void testGetDownloader() throws Exception {
        assertNotNull(Baba.getDownloader());
    }

    @Test
    public void testGetName() throws Exception {
        assertFalse(extractor.getName().isEmpty());
    }

    @Test
    public void testId() throws Exception {
        assertEquals(extractor.getId(), "Trending");
    }

    @Test
    public void testGetStreamsQuantity() throws Exception {
        ListExtractor.InfoItemsPage<StreamInfoItem> page = extractor.getInitialPage();
        Utils.printErrors(page.getErrors());
        assertTrue("no streams are received", page.getItems().size() >= 20);
    }

    @Test
    public void testGetStreamsErrors() throws Exception {
        ExtractorAsserts.assertEmptyErrors("errors during stream list extraction", extractor.getInitialPage().getErrors());
    }

    @Test
    public void testHasMoreStreams() throws Exception {
        // Setup the streams
        extractor.getInitialPage();
        TestCase.assertFalse("has more streams", extractor.hasNextPage());
    }

    @Test
    public void testGetNextPage() {
        assertTrue("yapti has next streams", extractor.getPage(extractor.getNextPageUrl()) == null
                || extractor.getPage(extractor.getNextPageUrl()).getItems().isEmpty());
    }

    @Test
    public void testGetUrl() throws Exception {
        Assert.assertEquals(extractor.getUrl(), extractor.getUrl(), "https://www.youtube.com/feed/trending");
    }
}

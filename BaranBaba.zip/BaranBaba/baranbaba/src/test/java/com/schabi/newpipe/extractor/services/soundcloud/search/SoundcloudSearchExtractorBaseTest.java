package com.schabi.newpipe.extractor.services.soundcloud.search;

import com.baran.baba.yapti.InfoItem;
import com.baran.baba.yapti.ListExtractor;
import com.baran.baba.yapti.services.soundcloud.SoundcloudSearchExtractor;

import org.junit.Test;

import static org.junit.Assert.assertTrue;


public abstract class SoundcloudSearchExtractorBaseTest {

    protected static SoundcloudSearchExtractor extractor;
    protected static ListExtractor.InfoItemsPage<InfoItem> itemsPage;


    protected static String removeClientId(String url) {
        String[] splitUrl = url.split("client_id=[a-zA-Z0-9]*&");
        return splitUrl[0] + splitUrl[1];
    }

    @Test
    public void testResultListElementsLength() {
        assertTrue(Integer.toString(itemsPage.getItems().size()),
                itemsPage.getItems().size() >= 3);
    }

    @Test
    public void testUrl() throws Exception {
        assertTrue(extractor.getUrl(), extractor.getUrl().startsWith("https://api-v2.soundcloud.com/search"));
    }
}

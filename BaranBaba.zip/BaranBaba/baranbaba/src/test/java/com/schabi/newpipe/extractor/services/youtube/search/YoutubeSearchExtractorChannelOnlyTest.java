package com.schabi.newpipe.extractor.services.youtube.search;

import com.schabi.newpipe.DownloaderTestImpl;
import com.baran.baba.yapti.InfoItem;
import com.baran.baba.yapti.ListExtractor;
import com.baran.baba.yapti.Baba;
import com.baran.baba.yapti.ServiceList;
import com.baran.baba.yapti.channel.ChannelInfoItem;
import com.baran.baba.yapti.services.youtube.extractors.YoutubeSearchExtractor;
import com.baran.baba.yapti.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory;

import org.hamcrest.CoreMatchers;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import static java.util.Arrays.asList;
import static org.junit.Assert.*;

public class YoutubeSearchExtractorChannelOnlyTest extends YoutubeSearchExtractorBaseTest {

    @BeforeClass
    public static void setUpClass() throws Exception {
        Baba.init(DownloaderTestImpl.getInstance());
        extractor = (YoutubeSearchExtractor) ServiceList.YouTube.getSearchExtractor("pewdiepie",
                asList(YoutubeSearchQueryHandlerFactory.CHANNELS), null);
        extractor.fetchPage();
        itemsPage = extractor.getInitialPage();
    }

    @Test
    public void testGetSecondPage() throws Exception {
        YoutubeSearchExtractor secondExtractor = (YoutubeSearchExtractor) ServiceList.YouTube.getSearchExtractor("pewdiepie",
                asList(YoutubeSearchQueryHandlerFactory.CHANNELS), null);
        ListExtractor.InfoItemsPage<InfoItem> secondPage = secondExtractor.getPage(itemsPage.getNextPageUrl());
        assertTrue(Integer.toString(secondPage.getItems().size()),
                secondPage.getItems().size() > 10);

        // check if its the same result
        boolean equals = true;
        for (int i = 0; i < secondPage.getItems().size()
                && i < itemsPage.getItems().size(); i++) {
            if (!secondPage.getItems().get(i).getUrl().equals(
                    itemsPage.getItems().get(i).getUrl())) {
                equals = false;
            }
        }
        assertFalse("First and second page are equal", equals);

        assertEquals("https://www.youtube.com/results?q=pewdiepie&sp=EgIQAlAU&gl=GB&page=3", secondPage.getNextPageUrl());
    }

    @Test
    public void testGetSecondPageUrl() throws Exception {
        assertEquals("https://www.youtube.com/results?q=pewdiepie&sp=EgIQAlAU&gl=GB&page=2", extractor.getNextPageUrl());
    }

    @Ignore
    @Test
    public void testOnlyContainChannels() {
        for(InfoItem item : itemsPage.getItems()) {
            if (!(item instanceof ChannelInfoItem)) {
                fail("The following item is no channel item: " + item.toString());
            }
        }
    }

    @Test
    public void testChannelUrl() {
        for(InfoItem item : itemsPage.getItems()) {
            if (item instanceof ChannelInfoItem) {
                ChannelInfoItem channel = (ChannelInfoItem) item;

                if (channel.getSubscriberCount() > 5e7) { // the real PewDiePie
                    assertEquals("https://www.youtube.com/channel/UC-lHJZR3Gqxm24_Vd_AJ5Yw", item.getUrl());
                } else {
                    assertThat(item.getUrl(), CoreMatchers.startsWith("https://www.youtube.com/channel/"));
                }
            }
        }
    }

    @Test
    public void testStreamCount() {
        ChannelInfoItem ci = (ChannelInfoItem) itemsPage.getItems().get(0);
        assertTrue("Stream count does not fit: " + ci.getStreamCount(),
                4000 < ci.getStreamCount() && ci.getStreamCount() < 5500);
    }
}

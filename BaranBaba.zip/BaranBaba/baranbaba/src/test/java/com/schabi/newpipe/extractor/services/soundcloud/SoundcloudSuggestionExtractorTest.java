package com.schabi.newpipe.extractor.services.soundcloud;

import com.schabi.newpipe.DownloaderTestImpl;
import com.baran.baba.yapti.Baba;
import com.baran.baba.yapti.ServiceList;
import com.baran.baba.yapti.exceptions.ExtractionException;
import com.baran.baba.yapti.suggestion.SuggestionExtractor;

import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.assertFalse;

/**
 * Test for {@link SuggestionExtractor}
 */
public class SoundcloudSuggestionExtractorTest {
    private static SuggestionExtractor suggestionExtractor;

    @BeforeClass
    public static void setUp() {
        Baba.init(DownloaderTestImpl.getInstance());
        suggestionExtractor = ServiceList.SoundCloud.getSuggestionExtractor();
    }

    @Test
    public void testIfSuggestions() throws IOException, ExtractionException {
        assertFalse(suggestionExtractor.suggestionList("lil uzi vert").isEmpty());
    }
}

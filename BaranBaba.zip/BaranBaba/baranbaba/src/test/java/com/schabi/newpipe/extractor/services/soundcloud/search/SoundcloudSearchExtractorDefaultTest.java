package com.schabi.newpipe.extractor.services.soundcloud.search;

import com.schabi.newpipe.DownloaderTestImpl;
import com.baran.baba.yapti.InfoItem;
import com.baran.baba.yapti.ListExtractor;
import com.baran.baba.yapti.Baba;
import com.baran.baba.yapti.ServiceList;
import com.baran.baba.yapti.services.soundcloud.SoundcloudSearchExtractor;
import com.baran.baba.yapti.services.soundcloud.SoundcloudSearchQueryHandlerFactory;
import com.baran.baba.yapti.services.youtube.extractors.YoutubeSearchExtractor;
import com.baran.baba.yapti.stream.StreamInfoItem;

import org.junit.BeforeClass;
import org.junit.Test;

import java.util.Arrays;

import static org.junit.Assert.*;


public class SoundcloudSearchExtractorDefaultTest extends SoundcloudSearchExtractorBaseTest {

    @BeforeClass
    public static void setUpClass() throws Exception {
        Baba.init(DownloaderTestImpl.getInstance());
        extractor = (SoundcloudSearchExtractor) ServiceList.SoundCloud.getSearchExtractor(
                new SoundcloudSearchQueryHandlerFactory().fromQuery("lill uzi vert",
                        Arrays.asList(new String[]{"tracks"}), ""));
        extractor.fetchPage();
        itemsPage = extractor.getInitialPage();
    }

    @Test
    public void testGetSecondPageUrl() throws Exception {
        assertEquals("https://api-v2.soundcloud.com/search/tracks?q=lill+uzi+vert&limit=10&offset=10",
                removeClientId(extractor.getNextPageUrl()));
    }

    @Test
    public void testResultListCheckIfContainsStreamItems() {
        boolean hasStreams = false;
        for(InfoItem item : itemsPage.getItems()) {
            if(item instanceof StreamInfoItem) {
                hasStreams = true;
            }
        }
        assertTrue("Has no InfoItemStreams", hasStreams);
    }

    @Test
    public void testGetSecondPage() throws Exception {
        SoundcloudSearchExtractor secondExtractor =
                (SoundcloudSearchExtractor) ServiceList.SoundCloud.getSearchExtractor("lill uzi vert");
        ListExtractor.InfoItemsPage<InfoItem> secondPage = secondExtractor.getPage(itemsPage.getNextPageUrl());
        assertTrue(Integer.toString(secondPage.getItems().size()),
                secondPage.getItems().size() >= 10);

        // check if its the same result
        boolean equals = true;
        for (int i = 0; i < secondPage.getItems().size()
                && i < itemsPage.getItems().size(); i++) {
            if(!secondPage.getItems().get(i).getUrl().equals(
                    itemsPage.getItems().get(i).getUrl())) {
                equals = false;
            }
        }
        assertFalse("First and second page are equal", equals);

        assertEquals("https://api-v2.soundcloud.com/search/tracks?q=lill+uzi+vert&limit=10&offset=20",
                removeClientId(secondPage.getNextPageUrl()));
    }


    @Test
    public void testId() throws Exception {
        assertEquals("lill uzi vert", extractor.getId());
    }

    @Test
    public void testName() {
        assertEquals("lill uzi vert", extractor.getName());
    }
}

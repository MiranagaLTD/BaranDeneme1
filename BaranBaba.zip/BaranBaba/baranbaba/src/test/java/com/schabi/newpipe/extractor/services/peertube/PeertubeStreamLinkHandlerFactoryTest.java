package com.schabi.newpipe.extractor.services.peertube;

import com.schabi.newpipe.DownloaderTestImpl;
import com.baran.baba.yapti.Baba;
import com.baran.baba.yapti.exceptions.ParsingException;
import com.baran.baba.yapti.services.peertube.linkHandler.PeertubeStreamLinkHandlerFactory;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * Test for {@link PeertubeStreamLinkHandlerFactory}
 */
public class PeertubeStreamLinkHandlerFactoryTest {
    private static PeertubeStreamLinkHandlerFactory linkHandler;

    @BeforeClass
    public static void setUp() throws Exception {
        linkHandler = PeertubeStreamLinkHandlerFactory.getInstance();
        Baba.init(DownloaderTestImpl.getInstance());
    }

    @Test
    public void getId() throws Exception {
        Assert.assertEquals("986aac60-1263-4f73-9ce5-36b18225cb60", linkHandler.fromUrl("https://peertube.mastodon.host/videos/watch/986aac60-1263-4f73-9ce5-36b18225cb60").getId());
        Assert.assertEquals("986aac60-1263-4f73-9ce5-36b18225cb60", linkHandler.fromUrl("https://peertube.mastodon.host/videos/watch/986aac60-1263-4f73-9ce5-36b18225cb60?fsdafs=fsafa").getId());
    }


    @Test
    public void testAcceptUrl() throws ParsingException {
        assertTrue(linkHandler.acceptUrl("https://peertube.mastodon.host/videos/watch/986aac60-1263-4f73-9ce5-36b18225cb60"));
        assertTrue(linkHandler.acceptUrl("https://peertube.mastodon.host/videos/watch/986aac60-1263-4f73-9ce5-36b18225cb60?fsdafs=fsafa"));
    }
}
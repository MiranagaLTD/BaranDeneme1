package com.schabi.newpipe.extractor.services.youtube.search;

import com.baran.baba.yapti.InfoItem;
import com.baran.baba.yapti.ListExtractor;
import com.baran.baba.yapti.services.youtube.extractors.YoutubeSearchExtractor;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;



public abstract class YoutubeSearchExtractorBaseTest {

    protected static YoutubeSearchExtractor extractor;
    protected static ListExtractor.InfoItemsPage<InfoItem> itemsPage;


    @Test
    public void testResultListElementsLength() {
        assertTrue(Integer.toString(itemsPage.getItems().size()),
                itemsPage.getItems().size() > 10);
    }

    @Test
    public void testUrl() throws Exception {
        assertTrue(extractor.getUrl(), extractor.getUrl().startsWith("https://www.youtube.com"));
    }
}

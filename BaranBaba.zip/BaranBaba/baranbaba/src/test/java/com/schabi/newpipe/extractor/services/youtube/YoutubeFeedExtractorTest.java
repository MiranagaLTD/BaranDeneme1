package com.schabi.newpipe.extractor.services.youtube;

import com.schabi.newpipe.DownloaderTestImpl;
import com.baran.baba.yapti.Baba;
import com.baran.baba.yapti.ServiceList;
import com.baran.baba.yapti.exceptions.ParsingException;
import com.schabi.newpipe.extractor.services.DefaultTests;
import com.baran.baba.yapti.services.youtube.extractors.YoutubeFeedExtractor;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.schabi.newpipe.extractor.services.BaseListExtractorTest;

import static org.junit.Assert.*;

public class YoutubeFeedExtractorTest {
    public static class Kurzgesagt implements BaseListExtractorTest {
        private static YoutubeFeedExtractor extractor;

        @BeforeClass
        public static void setUp() throws Exception {
            Baba.init(DownloaderTestImpl.getInstance());
            extractor = (YoutubeFeedExtractor) ServiceList.YouTube
                    .getFeedExtractor("https://www.youtube.com/user/Kurzgesagt");
            extractor.fetchPage();
        }

        /*//////////////////////////////////////////////////////////////////////////
        // Extractor
        //////////////////////////////////////////////////////////////////////////*/

        @Test
        public void testServiceId() {
            Assert.assertEquals(ServiceList.YouTube.getServiceId(), extractor.getServiceId());
        }

        @Test
        public void testName() {
            String name = extractor.getName();
            assertTrue(name, name.startsWith("Kurzgesagt"));
        }

        @Test
        public void testId() {
            assertEquals("UCsXVk37bltHxD1rDPwtNM8Q", extractor.getId());
        }

        @Test
        public void testUrl() {
            assertEquals("https://www.youtube.com/channel/UCsXVk37bltHxD1rDPwtNM8Q", extractor.getUrl());
        }

        @Test
        public void testOriginalUrl() throws ParsingException {
            Assert.assertEquals("https://www.youtube.com/user/Kurzgesagt", extractor.getOriginalUrl());
        }

        /*//////////////////////////////////////////////////////////////////////////
        // ListExtractor
        //////////////////////////////////////////////////////////////////////////*/

        @Test
        public void testRelatedItems() throws Exception {
            DefaultTests.defaultTestRelatedItems(extractor, ServiceList.YouTube.getServiceId());
        }

        @Test
        public void testMoreRelatedItems() {
            assertFalse(extractor.hasNextPage());
            assertNull(extractor.getNextPageUrl());
        }
    }
}
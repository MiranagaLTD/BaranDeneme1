package com.schabi.newpipe.extractor.services.media_ccc;

import com.schabi.newpipe.DownloaderTestImpl;
import com.baran.baba.yapti.Baba;
import com.baran.baba.yapti.ServiceList;
import com.baran.baba.yapti.channel.ChannelExtractor;
import com.baran.baba.yapti.services.media_ccc.extractors.MediaCCCConferenceExtractor;

import junit.framework.TestCase;

import org.junit.BeforeClass;
import org.junit.Test;

import static junit.framework.TestCase.assertEquals;

/**
 * Test {@link MediaCCCConferenceExtractor}
 */
public class MediaCCCConferenceExtractorTest {
    private static ChannelExtractor extractor;

    @BeforeClass
    public static void setUpClass() throws Exception {
        Baba.init(DownloaderTestImpl.getInstance());
        extractor = ServiceList.MediaCCC.getChannelExtractor("https://api.media.ccc.de/public/conferences/froscon2017");
        extractor.fetchPage();
    }

    @Test
    public void testName() throws Exception {
        TestCase.assertEquals("FrOSCon 2017", extractor.getName());
    }

    @Test
    public void testGetUrl() throws Exception {
        TestCase.assertEquals("https://api.media.ccc.de/public/conferences/froscon2017", extractor.getUrl());
    }

    @Test
    public void testGetOriginalUrl() throws Exception {
        TestCase.assertEquals("https://media.ccc.de/c/froscon2017", extractor.getOriginalUrl());
    }

    @Test
    public void testGetThumbnailUrl() throws Exception {
        assertEquals("https://static.media.ccc.de/media/events/froscon/2017/logo.png", extractor.getAvatarUrl());
    }

    @Test
    public void testGetInitalPage() throws Exception {
        TestCase.assertEquals(97,extractor.getInitialPage().getItems().size());
    }
}

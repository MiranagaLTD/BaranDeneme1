package com.schabi.newpipe.extractor.services.youtube;



import com.schabi.newpipe.DownloaderTestImpl;
import com.baran.baba.yapti.Baba;
import com.baran.baba.yapti.ServiceList;
import com.baran.baba.yapti.exceptions.ExtractionException;
import com.baran.baba.yapti.localization.Localization;
import com.baran.baba.yapti.suggestion.SuggestionExtractor;

import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.assertFalse;

/**
 * Test for {@link SuggestionExtractor}
 */
public class YoutubeSuggestionExtractorTest {
    private static SuggestionExtractor suggestionExtractor;

    @BeforeClass
    public static void setUp() throws Exception {
        Baba.init(DownloaderTestImpl.getInstance(), new Localization("de", "DE"));
        suggestionExtractor = ServiceList.YouTube.getSuggestionExtractor();
    }

    @Test
    public void testIfSuggestions() throws IOException, ExtractionException {
        assertFalse(suggestionExtractor.suggestionList("hello").isEmpty());
    }
}

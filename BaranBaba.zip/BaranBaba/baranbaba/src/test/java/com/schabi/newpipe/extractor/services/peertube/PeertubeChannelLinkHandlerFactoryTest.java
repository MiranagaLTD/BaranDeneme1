package com.schabi.newpipe.extractor.services.peertube;

import com.schabi.newpipe.DownloaderTestImpl;
import com.baran.baba.yapti.Baba;
import com.baran.baba.yapti.exceptions.ParsingException;
import com.baran.baba.yapti.services.peertube.linkHandler.PeertubeChannelLinkHandlerFactory;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * Test for {@link PeertubeChannelLinkHandlerFactory}
 */
public class PeertubeChannelLinkHandlerFactoryTest {

    private static PeertubeChannelLinkHandlerFactory linkHandler;

    @BeforeClass
    public static void setUp() {
        linkHandler = PeertubeChannelLinkHandlerFactory.getInstance();
        Baba.init(DownloaderTestImpl.getInstance());
    }

    @Test
    public void acceptUrlTest() throws ParsingException {
        assertTrue(linkHandler.acceptUrl("https://peertube.mastodon.host/accounts/kranti@videos.squat.net"));
    }

    @Test
    public void getIdFromUrl() throws ParsingException {
        Assert.assertEquals("kranti@videos.squat.net", linkHandler.fromUrl("https://peertube.mastodon.host/accounts/kranti@videos.squat.net").getId());
        Assert.assertEquals("kranti@videos.squat.net", linkHandler.fromUrl("https://peertube.mastodon.host/accounts/kranti@videos.squat.net/videos").getId());
    }
}

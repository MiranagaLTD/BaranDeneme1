package com.schabi.newpipe.extractor.services.peertube;

import com.baran.baba.yapti.services.peertube.PeertubeInstance;
import com.schabi.newpipe.DownloaderTestImpl;
import com.baran.baba.yapti.ListExtractor;
import com.baran.baba.yapti.Baba;
import com.baran.baba.yapti.ServiceList;
import com.baran.baba.yapti.kiosk.KioskExtractor;
import com.baran.baba.yapti.services.peertube.extractors.PeertubeTrendingExtractor;
import com.baran.baba.yapti.stream.StreamInfoItem;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * Test for {@link PeertubeTrendingExtractor}
 */
public class PeertubeTrendingExtractorTest {

    static KioskExtractor extractor;

    @BeforeClass
    public static void setUp() throws Exception {
        Baba.init(DownloaderTestImpl.getInstance());
        // setting instance might break test when running in parallel
        ServiceList.PeerTube.setInstance(new PeertubeInstance("https://peertube.mastodon.host", "PeerTube on Mastodon.host"));
        extractor = ServiceList.PeerTube
                .getKioskList()
                .getExtractorById("Trending", null);
        extractor.fetchPage();
    }

    @Test
    public void testGetDownloader() throws Exception {
        assertNotNull(Baba.getDownloader());
    }

    @Test
    public void testGetName() throws Exception {
        assertEquals(extractor.getName(), "Trending");
    }

    @Test
    public void testId() {
        assertEquals(extractor.getId(), "Trending");
    }

    @Test
    public void testGetStreams() throws Exception {
        ListExtractor.InfoItemsPage<StreamInfoItem> page = extractor.getInitialPage();
        if(!page.getErrors().isEmpty()) {
            System.err.println("----------");
            List<Throwable> errors = page.getErrors();
            for(Throwable e: errors) {
                e.printStackTrace();
                System.err.println("----------");
            }
        }
        assertTrue("no streams are received",
                !page.getItems().isEmpty()
                        && page.getErrors().isEmpty());
    }

    @Test
    public void testGetStreamsErrors() throws Exception {
        assertTrue("errors during stream list extraction", extractor.getInitialPage().getErrors().isEmpty());
    }

    @Test
    public void testHasMoreStreams() throws Exception {
        // Setup the streams
        extractor.getInitialPage();
        assertTrue("has more streams", extractor.hasNextPage());
    }

    @Test
    public void testGetNextPageUrl() throws Exception {
        assertTrue(extractor.hasNextPage());
    }

    @Test
    public void testGetNextPage() throws Exception {
        extractor.getInitialPage().getItems();
        assertFalse("yapti has next streams", extractor.getPage(extractor.getNextPageUrl()) == null
                || extractor.getPage(extractor.getNextPageUrl()).getItems().isEmpty());
    }

    @Test
    public void testGetCleanUrl() throws Exception {
        Assert.assertEquals(extractor.getUrl(), "https://peertube.mastodon.host/api/v1/videos?sort=-trending");
    }
}

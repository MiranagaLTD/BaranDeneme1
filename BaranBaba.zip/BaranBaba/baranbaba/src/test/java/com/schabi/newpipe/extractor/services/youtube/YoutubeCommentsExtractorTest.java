package com.schabi.newpipe.extractor.services.youtube;

import com.schabi.newpipe.DownloaderTestImpl;
import com.baran.baba.yapti.ListExtractor;
import com.baran.baba.yapti.Baba;
import com.baran.baba.yapti.ServiceList;
import com.baran.baba.yapti.comments.CommentsInfo;
import com.baran.baba.yapti.comments.CommentsInfoItem;
import com.baran.baba.yapti.exceptions.ExtractionException;
import com.schabi.newpipe.extractor.services.DefaultTests;
import com.baran.baba.yapti.services.youtube.extractors.YoutubeCommentsExtractor;

import org.jsoup.helper.StringUtil;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;
import java.util.List;

import static org.junit.Assert.*;

public class YoutubeCommentsExtractorTest {

    private static final String urlYT = "https://www.youtube.com/watch?v=D00Au7k3i6o";
    private static final String urlInvidious = "https://invidio.us/watch?v=D00Au7k3i6o";
    private static final String urlInvidioush = "https://invidiou.sh/watch?v=D00Au7k3i6o";
    private static YoutubeCommentsExtractor extractorYT;
    private static YoutubeCommentsExtractor extractorInvidious;
    private static YoutubeCommentsExtractor extractorInvidioush;

    @BeforeClass
    public static void setUp() throws Exception {
        Baba.init(DownloaderTestImpl.getInstance());
        extractorYT = (YoutubeCommentsExtractor) ServiceList.YouTube
                .getCommentsExtractor(urlYT);
        extractorInvidious = (YoutubeCommentsExtractor) ServiceList.YouTube
                .getCommentsExtractor(urlInvidious);
        extractorInvidioush = (YoutubeCommentsExtractor) ServiceList.YouTube
                .getCommentsExtractor(urlInvidioush);
    }

    @Test
    public void testGetComments() throws IOException, ExtractionException {
        assertTrue(getCommentsHelper(extractorYT));
        assertTrue(getCommentsHelper(extractorInvidious));
        assertTrue(getCommentsHelper(extractorInvidioush));
    }

    private boolean getCommentsHelper(YoutubeCommentsExtractor extractor) throws IOException, ExtractionException {
        boolean result;
        ListExtractor.InfoItemsPage<CommentsInfoItem> comments = extractor.getInitialPage();
        result = findInComments(comments, "s1ck m3m3");

        while (comments.hasNextPage() && !result) {
            comments = extractor.getPage(comments.getNextPageUrl());
            result = findInComments(comments, "s1ck m3m3");
        }

        return result;
    }

    @Test
    public void testGetCommentsFromCommentsInfo() throws IOException, ExtractionException {
        assertTrue(getCommentsFromCommentsInfoHelper(urlYT));
        assertTrue(getCommentsFromCommentsInfoHelper(urlInvidious));
        assertTrue(getCommentsFromCommentsInfoHelper(urlInvidioush));
    }

    private boolean getCommentsFromCommentsInfoHelper(String url) throws IOException, ExtractionException {
        boolean result = false;
        CommentsInfo commentsInfo = CommentsInfo.getInfo(url);
        Assert.assertEquals("what the fuck am i doing with my life", commentsInfo.getName());
        result = findInComments(commentsInfo.getRelatedItems(), "s1ck m3m3");

        String nextPage = commentsInfo.getNextPageUrl();
        while (!StringUtil.isBlank(nextPage) && !result) {
            ListExtractor.InfoItemsPage<CommentsInfoItem> moreItems = CommentsInfo.getMoreItems(ServiceList.YouTube, commentsInfo, nextPage);
            result = findInComments(moreItems.getItems(), "s1ck m3m3");
            nextPage = moreItems.getNextPageUrl();
        }
        return result;
    }

    @Test
    public void testGetCommentsAllData() throws IOException, ExtractionException {
        ListExtractor.InfoItemsPage<CommentsInfoItem> comments = extractorYT.getInitialPage();

        DefaultTests.defaultTestListOfItems(ServiceList.YouTube.getServiceId(), comments.getItems(), comments.getErrors());
        for (CommentsInfoItem c : comments.getItems()) {
            assertFalse(StringUtil.isBlank(c.getAuthorEndpoint()));
            assertFalse(StringUtil.isBlank(c.getAuthorName()));
            assertFalse(StringUtil.isBlank(c.getAuthorThumbnail()));
            assertFalse(StringUtil.isBlank(c.getCommentId()));
            assertFalse(StringUtil.isBlank(c.getCommentText()));
            assertFalse(StringUtil.isBlank(c.getName()));
            assertFalse(StringUtil.isBlank(c.getTextualPublishedTime()));
            assertNotNull(c.getPublishedTime());
            assertFalse(StringUtil.isBlank(c.getThumbnailUrl()));
            assertFalse(StringUtil.isBlank(c.getUrl()));
            assertFalse(c.getLikeCount() < 0);
        }
    }

    private boolean findInComments(ListExtractor.InfoItemsPage<CommentsInfoItem> comments, String comment) {
        return findInComments(comments.getItems(), comment);
    }

    private boolean findInComments(List<CommentsInfoItem> comments, String comment) {
        for (CommentsInfoItem c : comments) {
            if (c.getCommentText().contains(comment)) {
                return true;
            }
        }
        return false;
    }
}

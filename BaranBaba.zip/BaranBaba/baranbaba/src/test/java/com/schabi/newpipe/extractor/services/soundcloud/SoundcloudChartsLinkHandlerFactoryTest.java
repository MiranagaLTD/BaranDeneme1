package com.schabi.newpipe.extractor.services.soundcloud;

import com.baran.baba.yapti.services.soundcloud.SoundcloudChartsLinkHandlerFactory;
import com.schabi.newpipe.DownloaderTestImpl;
import com.baran.baba.yapti.Baba;
import com.baran.baba.yapti.exceptions.ParsingException;

import junit.framework.TestCase;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import static junit.framework.TestCase.assertFalse;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Test for {@link SoundcloudChartsLinkHandlerFactory}
 */
public class SoundcloudChartsLinkHandlerFactoryTest {
    private static SoundcloudChartsLinkHandlerFactory linkHandler;

    @BeforeClass
    public static void setUp() {
        linkHandler = new SoundcloudChartsLinkHandlerFactory();
        Baba.init(DownloaderTestImpl.getInstance());
    }

    @Test
    public void getUrl() throws Exception {
        Assert.assertEquals(linkHandler.fromId("Top 50").getUrl(), "https://soundcloud.com/charts/top");
        Assert.assertEquals(linkHandler.fromId("New & hot").getUrl(), "https://soundcloud.com/charts/new");
    }

    @Test
    public void getId() throws ParsingException {
        Assert.assertEquals(linkHandler.fromUrl("http://soundcloud.com/charts/top?genre=all-music").getId(), "Top 50");
        Assert.assertEquals(linkHandler.fromUrl("HTTP://www.soundcloud.com/charts/new/?genre=all-music&country=all-countries").getId(), "New & hot");
    }

    @Test
    public void acceptUrl() throws ParsingException {
        assertTrue(linkHandler.acceptUrl("https://soundcloud.com/charts"));
        assertTrue(linkHandler.acceptUrl("https://soundcloud.com/charts/"));
        assertTrue(linkHandler.acceptUrl("https://www.soundcloud.com/charts/new"));
        assertTrue(linkHandler.acceptUrl("http://soundcloud.com/charts/top?genre=all-music"));
        assertTrue(linkHandler.acceptUrl("HTTP://www.soundcloud.com/charts/new/?genre=all-music&country=all-countries"));

        TestCase.assertFalse(linkHandler.acceptUrl("kdskjfiiejfia"));
        TestCase.assertFalse(linkHandler.acceptUrl("soundcloud.com/charts askjkf"));
        TestCase.assertFalse(linkHandler.acceptUrl("    soundcloud.com/charts"));
        TestCase.assertFalse(linkHandler.acceptUrl(""));
    }
}

package com.schabi.newpipe.extractor.services.soundcloud;

import com.baran.baba.yapti.services.soundcloud.SoundcloudChannelExtractor;
import com.schabi.newpipe.DownloaderTestImpl;
import com.schabi.newpipe.extractor.ExtractorAsserts;
import com.baran.baba.yapti.Baba;
import com.baran.baba.yapti.ServiceList;
import com.baran.baba.yapti.channel.ChannelExtractor;
import com.baran.baba.yapti.exceptions.ParsingException;
import com.schabi.newpipe.extractor.services.BaseChannelExtractorTest;
import com.schabi.newpipe.extractor.services.DefaultTests;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;
import static com.schabi.newpipe.extractor.ExtractorAsserts.assertEmpty;

/**
 * Test for {@link SoundcloudChannelExtractor}
 */
public class SoundcloudChannelExtractorTest {
    public static class LilUzi implements BaseChannelExtractorTest {
        private static SoundcloudChannelExtractor extractor;

        @BeforeClass
        public static void setUp() throws Exception {
            Baba.init(DownloaderTestImpl.getInstance());
            extractor = (SoundcloudChannelExtractor) ServiceList.SoundCloud
                    .getChannelExtractor("http://soundcloud.com/liluzivert/sets");
            extractor.fetchPage();
        }

        /*//////////////////////////////////////////////////////////////////////////
        // Extractor
        //////////////////////////////////////////////////////////////////////////*/

        @Test
        public void testServiceId() {
            Assert.assertEquals(ServiceList.SoundCloud.getServiceId(), extractor.getServiceId());
        }

        @Test
        public void testName() {
            assertEquals("LIL UZI VERT", extractor.getName());
        }

        @Test
        public void testId() {
            assertEquals("10494998", extractor.getId());
        }

        @Test
        public void testUrl() throws ParsingException {
            Assert.assertEquals("https://soundcloud.com/liluzivert", extractor.getUrl());
        }

        @Test
        public void testOriginalUrl() throws ParsingException {
            Assert.assertEquals("http://soundcloud.com/liluzivert/sets", extractor.getOriginalUrl());
        }

        /*//////////////////////////////////////////////////////////////////////////
        // ListExtractor
        //////////////////////////////////////////////////////////////////////////*/

        @Test
        public void testRelatedItems() throws Exception {
            DefaultTests.defaultTestRelatedItems(extractor, ServiceList.SoundCloud.getServiceId());
        }

        @Test
        public void testMoreRelatedItems() throws Exception {
            DefaultTests.defaultTestMoreItems(extractor, ServiceList.SoundCloud.getServiceId());
        }

        /*//////////////////////////////////////////////////////////////////////////
        // ChannelExtractor
        //////////////////////////////////////////////////////////////////////////*/

        @Test
        public void testDescription() {
            assertNotNull(extractor.getDescription());
        }

        @Test
        public void testAvatarUrl() {
            ExtractorAsserts.assertIsSecureUrl(extractor.getAvatarUrl());
        }

        @Test
        public void testBannerUrl() {
            ExtractorAsserts.assertIsSecureUrl(extractor.getBannerUrl());
        }

        @Test
        public void testFeedUrl() {
            ExtractorAsserts.assertEmpty(extractor.getFeedUrl());
        }

        @Test
        public void testSubscriberCount() {
            assertTrue("Wrong subscriber count", extractor.getSubscriberCount() >= 1e6);
        }
    }

    public static class DubMatix implements BaseChannelExtractorTest {
        private static SoundcloudChannelExtractor extractor;

        @BeforeClass
        public static void setUp() throws Exception {
            Baba.init(DownloaderTestImpl.getInstance());
            extractor = (SoundcloudChannelExtractor) ServiceList.SoundCloud
                    .getChannelExtractor("https://soundcloud.com/dubmatix");
            extractor.fetchPage();
        }

        /*//////////////////////////////////////////////////////////////////////////
        // Additional Testing
        //////////////////////////////////////////////////////////////////////////*/

        @Test
        public void testGetPageInNewExtractor() throws Exception {
            final ChannelExtractor newExtractor = ServiceList.SoundCloud.getChannelExtractor(extractor.getUrl());
            DefaultTests.defaultTestGetPageInNewExtractor(extractor, newExtractor, ServiceList.SoundCloud.getServiceId());
        }

        /*//////////////////////////////////////////////////////////////////////////
        // Extractor
        //////////////////////////////////////////////////////////////////////////*/

        @Test
        public void testServiceId() {
            Assert.assertEquals(ServiceList.SoundCloud.getServiceId(), extractor.getServiceId());
        }

        @Test
        public void testName() {
            assertEquals("dubmatix", extractor.getName());
        }

        @Test
        public void testId() {
            assertEquals("542134", extractor.getId());
        }

        @Test
        public void testUrl() throws ParsingException {
            Assert.assertEquals("https://soundcloud.com/dubmatix", extractor.getUrl());
        }

        @Test
        public void testOriginalUrl() throws ParsingException {
            Assert.assertEquals("https://soundcloud.com/dubmatix", extractor.getOriginalUrl());
        }

        /*//////////////////////////////////////////////////////////////////////////
        // ListExtractor
        //////////////////////////////////////////////////////////////////////////*/

        @Test
        public void testRelatedItems() throws Exception {
            DefaultTests.defaultTestRelatedItems(extractor, ServiceList.SoundCloud.getServiceId());
        }

        @Test
        public void testMoreRelatedItems() throws Exception {
            DefaultTests.defaultTestMoreItems(extractor, ServiceList.SoundCloud.getServiceId());
        }

        /*//////////////////////////////////////////////////////////////////////////
        // ChannelExtractor
        //////////////////////////////////////////////////////////////////////////*/

        @Test
        public void testDescription() {
            assertNotNull(extractor.getDescription());
        }

        @Test
        public void testAvatarUrl() {
            ExtractorAsserts.assertIsSecureUrl(extractor.getAvatarUrl());
        }

        @Test
        public void testBannerUrl() {
            ExtractorAsserts.assertIsSecureUrl(extractor.getBannerUrl());
        }

        @Test
        public void testFeedUrl() {
            ExtractorAsserts.assertEmpty(extractor.getFeedUrl());
        }

        @Test
        public void testSubscriberCount() {
            assertTrue("Wrong subscriber count", extractor.getSubscriberCount() >= 2e6);
        }
    }
}
